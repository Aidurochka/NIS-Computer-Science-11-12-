### **Stack and Queue Data Structures**

#### **1. Stack Data Structure**
[detailed breakdown](https://www.geeksforgeeks.org/stack-data-structure/) 
**Definition**:  
> A linear data structure that follows the **Last-In, First-Out (LIFO)** principle. The last element added is the first to be removed.

![[image-36.png|393x313]]

---
**Key Operations**:  

| **Operation** | **Description**                         |
| ------------- | --------------------------------------- |
| **Push**      | Adds an element to the top of the stack |
| **Pop**       | Removes the top element from the stack  |
| **Peek/Top**  | Returns the top element without removal |

**Implementation**:  
- Uses a **top** pointer to track the last inserted element.  
- Example (stack with elements `[5, 6, 9, 2, 4]`):  
  ```
  Index:   0   1   2   3   4  
  Value:   5   6   9   2   4 ← top  
  ```  

**Use Cases**:  
- Function call management (call stack).  
- Undo/redo operations in editors.  
- Syntax parsing (e.g., bracket matching).  

---

#### **2. Queue Data Structure**  
[detailed breakdown](https://www.geeksforgeeks.org/queue-data-structure/?ref=header_outind) 
**Definition**:  
> A linear data structure that follows the **First-In, First-Out (FIFO)** principle. The first element added is the first to be removed.  

![[image-35.png|468x250]]

---
**Key Operations**: 

| **Operation** | **Description**                                 |
| ------------- | ----------------------------------------------- |
| **Enqueue**   | Adds an element to the rear (end) of the queue  |
| **Dequeue**   | Removes the element from the front of the queue |
| **Front**     | Returns the front element without removal       |

**Implementation**:  
- Uses **front** and **rear** pointers.  
- Example (queue with elements `[7, 2, 6, 9, 1]`):  
  ```
  Index:   0   1   2   3   4   5  
  Value:   7   2   6   9   1  
           ↑               ↑  
         front            rear  
  ```  

**Use Cases**:  
- Task scheduling (e.g., CPU/print queues).  
- Breadth-First Search (BFS) in graphs.  
- Buffering data streams.  

---

### **Comparison: Stack vs. Queue**  
| **Feature**       | **Stack (LIFO)**          | **Queue (FIFO)**          |  
|-------------------|--------------------------|--------------------------|  
| **Insertion**     | `push()` at top          | `enqueue()` at rear      |  
| **Deletion**      | `pop()` from top         | `dequeue()` from front   |  
| **Pointers**      | Single `top` pointer     | `front` and `rear`       |  
| **Applications**  | Call stacks, undo/redo   | Task scheduling, BFS     |  

---

