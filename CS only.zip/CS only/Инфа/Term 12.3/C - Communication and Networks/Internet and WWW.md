### **Internet, WWW, and Intranet**

#### **1. World Wide Web (WWW)**
**Definition**:  
A system of interconnected hypertext documents and resources accessed via the Internet using HTTP/HTTPS protocols. Operates on a **client-server model**.

**Key Features**:  
- **Hyperlinks**: The ability to link pages and documents together using hyperlinks is a key feature of the WWW.
- **Web Browsers**: Software (e.g., Chrome, Firefox) are used to access and navigate the web
- **[[URL]]s (Uniform Resource Locators)**: Unique addresses for web resources (e.g., `https://example.com`). [[URL]]s are used to specify the location of a resource on the web
- **Multimedia Support**: Embeds images, audio, video, and interactive content.  
- **[[Protocols]]**: Primarily uses **HTTP/HTTP** for data transfer.  
more about URL - [[URL]]
more about HTTP - [[Protocols#**1. HTTP (Port 80) & HTTPS (Port 443)**|HTTP]]

**Technical Components**:  

| **Component**       | **Role**                                                                 |  
|---------------------|-------------------------------------------------------------------------|  
| **Web Servers**     | Host and deliver web pages (e.g., Apache, Nginx).                       |  
| **Clients**        | User devices (browsers) that request and display content.               |  
| **DNS**            | Translates domain names (e.g., `google.com`) to IP addresses.           |  

**Example**:  
Accessing `https://wikipedia.org` involves:  
1. DNS resolution → IP address.  
2. HTTP request to Wikipedia’s server.  
3. Server responds with HTML/CSS/JS → Browser renders the page.  

---

#### **2. Intranet**  
**Definition**:  
A **private network** within an organization, inaccessible to the public, used for internal communication and resource sharing.  

**Key Features**:  
- **Access Control**: Requires authentication (login/password).  
- **Collaboration Tools**: Includes:  
  - Shared calendars (e.g., Microsoft Outlook).  
  - Document sharing (e.g., SharePoint).  
  - Internal messaging/chat (e.g., Slack).  
- **Security**: Protected by:  
  - **Firewalls**: Block unauthorized external access.  
  - **[[Encryption]]**: Secures data in transit (e.g., VPNs).  
- *Isolation*: Typically disconnected from the public Internet to prevent breaches.  

**Use Cases**:  
- Employee portals for HR policies.  
- Secure file repositories (e.g., company financial records).  

---

#### **3. Internet**  
**Definition**:  
A **global network** of interconnected computers and networks enabling data exchange. Serves as the infrastructure for WWW, email, etc.  

**Key Features**:  
- **Global Reach**: Accessible worldwide (e.g., via ISPs).  
- **Public Access**: No authentication required for most services.  
- **Diverse Applications**:  
  - **Communication**: Email (SMTP), VoIP (Zoom).  
  - **File Transfer**: **[[Protocols#2. FTP (Port 21) & FTPS**|FTP]]**, cloud storage (Google Drive).  
  - **E-Commerce**: Online shopping (Amazon).  
- **Security Risks**:  
  - **Malware**: Viruses, ransomware.  
  - **Phishing**: Fraudulent websites/emails.  
  - **DDoS Attacks**: Overwhelming servers with traffic.  

**Protocols**:  

| **Protocol** | **Purpose**                        |
| ------------ | ---------------------------------- |
| **TCP/IP**   | Core communication protocol suite. |
| **HTTP**     | Web page transfer.                 |
| **FTP**      | File transfers.                    |
| **SMTP**     | Email sending.                     |
more about protocols - [[Protocols]]

---

### **Comparison Table**  
| **Feature**       | **WWW**                                  | **Intranet**                          | **Internet**                          |  
|-------------------|----------------------------------------|--------------------------------------|--------------------------------------|  
| **Access**        | Public (via browsers).                 | Private (employees only).            | Public (global).                     |  
| **Content**       | Hyperlinked documents/media.           | Internal resources/tools.            | All networked services.              |  
| **Security**      | HTTPS encryption.                      | Firewalls + VPNs.                    | Vulnerable to attacks.               |  
| **Example**       | `www.wikipedia.org`.                   | Company HR portal.                   | Email, cloud services.               |  

---

