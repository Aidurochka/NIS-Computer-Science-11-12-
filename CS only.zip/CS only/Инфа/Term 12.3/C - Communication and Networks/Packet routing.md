---
tags:
  - network
  - data-transmission
  - packet-routing
  - MAC
---

## **Packet routing**
#### **Definition**
> Packet routing is the process of directing data packets from a source device to a destination across a network. It involves:

1. **Addressing**:
    - Uses  **[[IP address| IP address (click)]]** (logical, network layer) for end-to-end routing.
    - Uses **MAC addresses** (physical, data link layer) for local network delivery.
2. **Routing Devices**
    - **[[Network equipment#2. Switch - Smart Hub|Switch (click)]]**: Use MAC addresses to forward packets within a local network.
    - **[[Network equipment#6. Router|Router (click)]]**: Use IP addresses to route packets between different networks (e.g., LAN to the internet).

### **MAC Adresses**

#### **1. Definition of MAC Addresses**
> A **MAC** (Media Access Control) address is a unique identifier assigned to a Network Interface Controller ([[Network equipment#5. Network Adapter (NIC)|NIC]]) for communication within a network segment. It is also known as the Physical Address of a device.

**Format**: 
  - 12-digit hexadecimal number (6-Byte binary number).
  - Typically represented in Colon-Hexadecimal notation (e.g., `00:40:96:1A:2B:3C`).
  - The first 6 digits (OUI - Organizational Unique Identifier) identify the manufacturer.
  - The remaining 6 digits represent the specific [[Network equipment#5. Network Adapter (NIC)|NIC (click)]].

#### **2. Role of MAC Addresses in Packet Routing**
**OSI Model Layer**: MAC addresses operate at the **[[OSI model#2. Data link layer**| Data link layer (layer 2) (click)]].**
##### **Function**:
  - When a packet is sent over a local network, it is encapsulated with a header containing the **source and destination MAC addresses**.
  - Network switches use the **destination MAC address** to determine where to forward the packet.
    - The switch checks its **MAC address table** to locate the destination device.
    - If the MAC address is not found, the switch **broadcasts** the packet to all devices on the network to locate the destination.
  - The destination device identifies the packet using the MAC address in the header and extracts the data.

#### **3. Importance of MAC Addresses**
- **Local Network Communication**: Essential for directing packets to the correct device within the same network segment.
- **Efficiency**: Reduces unnecessary traffic by enabling switches to forward packets directly to the intended device when possible.
- **Universality**: Used in most IEEE 802 networking technologies, including Ethernet, Wi-Fi, and Bluetooth.

#### **4. How to Identify a MAC Address**
- **On Windows**:
  1. Open the **Command Prompt** by typing `cmd` in the Start menu.
  2. Enter the command: `ipconfig /all`.
  3. Locate the network adapter and find the **Physical Address** (e.g., `00-1A-2B-3C-4D-5E`).
  
- **On Mac**:
  1. Open the **Terminal** app.
  2. Enter the command: `ifconfig`.
  3. Look for the **HWaddr** or similar section under the desired network adapter.
