---
tags:
  - packet-switching
  - circuit-switching
  - network
  - data-transmission
---

### **Packet Switching & Circuit Switching**

- **[[#Packet Switching]]**
- **[[#Circuit Switching]]**
- **[[#Comparison Table]]**
- **[[#Advantages and Disadvantages]]**



---
#### **Packet Switching**

- **Definition:**  
    A communication method where data is divided into smaller units called **packets** and transmitted over the network.
    
- **How It Works:**
    - Each packet contains:
        - Source address
        - Destination address
        - Routing information
   
    - Packets may take **different paths** through the network.
    - Packets may arrive **out of order** or be **delayed** due to network congestion.
- **Usage:**  
    Commonly used in **data communication** (e.g., Internet)


---
#### **Circuit Switching**

- **Definition:**  
    A communication method where a **dedicated communication path (circuit)** is established between two devices before data transmission begins.
    
- **How It Works:**
    
    - The circuit is **reserved for the entire session**.
        
    - No other devices can use the same circuit while the session is active.
        
- **Usage:**  
    Commonly used in **voice communication** and some types of data communication.
    

---
####  **Comparison Table**

| Feature              | Circuit Switching                  | Packet Switching                      |
| -------------------- | ---------------------------------- | ------------------------------------- |
| Path Requirement     | Requires a dedicated path          | No dedicated path required            |
| Bandwidth Allocation | Reserves bandwidth in advance      | Does not reserve bandwidth in advance |
| Transmission Method  | No store-and-forward               | Supports store-and-forward            |
| Routing Behavior     | Each packet follows the same route | Packets can follow different routes   |
| Setup Requirement    | Call setup is required             | No call setup required                |
| Bandwidth Efficiency | Possible bandwidth wastage         | No bandwidth wastage                  |


---
#### **Advantages and Disadvantages**

| Switching Type        | Advantages                                                                                                                                                        | Disadvantages                                                                                                                                                   |
| --------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Packet Switching**  | - Efficient use of bandwidth (no reservation needed) <br>- Can handle **large** amounts of data <br>- More **scalable** and **flexible** - No need for call setup | - Packets may arrive **out of order** <br>- Higher **latency** due to routing and congestion <br>- Requires complex protocols for reassembly and error checking |
| **Circuit Switching** | - Consistent and predictable **data flow** <br>- Ideal for **real-time communication** (e.g., voice calls) <br>- Lower latency once circuit is set up             | - **Inefficient use of bandwidth** (reserved even when idle) <br>- **Call setup delay** before data transfer <br>- Not scalable for large networks              |

