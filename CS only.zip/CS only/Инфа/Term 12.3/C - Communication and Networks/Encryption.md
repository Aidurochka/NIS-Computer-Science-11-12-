#### **Encryption and Access Rights**  
##### **Encryption**
> The process of converting data (**plaintext**) into an unreadable form (**ciphertext**) using an algorithm and **key**, ensuring only authorized users can decrypt it.  

#### **Purposes of Encryption**
- Verify authentic users.  
- Prevent message alteration.  
- Block unauthorized access to data.  

#### **Encryption Types**  
[Encryption types](https://preyproject.com/blog/types-of-encryption-symmetric-or-asymmetric-rsa-or-aes#types-of-encryption-systems) - good litlle article about everything you need to know about ecnryption types
##### **TLDR:**
- **Symmetric Encryption**: Uses the same key for encryption and decryption.  
- **Asymmetric Encryption**: Uses two different keys, a public key for encryption and a private key for decryption
###### **Difference in Key usage**
1. Symmetric Encryption :
      A **symmetric key** is one that may be used to encrypt and decode data. This implies that in order to decrypt information, the same key that was used to encrypt it must be utilized.
2. Asymmetric Encryption:
      A **public key** is available for anyone who needs to encrypt a piece of information. This key doesn’t work for the decryption process. A user needs to have a secondary key, the **private key**, to decrypt this information. This way, the **private key** is only held by the actor who **decrypts** the information, without sacrificing security as you scale security.


### **Authorization**
**Authorization**: Process by which a server determines if the client has permission
to use a resource or access a file.
**Authorization** is the control of a user’s access to computer
resources.
- Authorized users receive a user ID and password.  
- Permissions are managed by a system administrator.  
- Passwords and encryption safeguard data from unauthorized access.  