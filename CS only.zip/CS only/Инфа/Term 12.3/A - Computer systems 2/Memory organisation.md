---
tags:
  - memory
  - memory-management
---

### **Memory Organization  (12.3.4.2)**

#### **1. Memory Organization Principles**

**Definitions:**
##### **Segmentation**
- **Segmentation**: Memory management technique dividing physical memory into variable-sized blocks called "segments"
##### **Paging**
- **Paging**: Memory management technique dividing both physical and logical memory into fixed-size blocks called "pages"
---
#### **Comparison**

| **Characteristic**            | **Paging**                                                           | **Segmentation**                                                    |
| ----------------------------- | -------------------------------------------------------------------- | ------------------------------------------------------------------- |
| **Block Type**                | Fixed-size blocks called pages                                       | Variable-size blocks called segments                                |
| **Fragmentation**             | May cause internal fragmentation                                     | Reduces internal fragmentation but may cause external fragmentation |
| **Address Specification**     | User provides single value (hardware determines page size)           | User provides two values (segment number + segment size)            |
| **Mapping Mechanism**         | Page table maps logical→physical addresses (contains base addresses) | Segment map table uses segment number + offset                      |
| **Programmer Visibility**     | Essentially invisible to programmer                                  | Essentially visible to programmer                                   |
| **Procedure/Data Separation** | Cannot separate procedures and associated data                       | Can separate procedures and associated data                         |
| **Linking/Loading**           | Uses static linking and dynamic loading                              | Uses dynamic linking and dynamic loading                            |

[detailed breakdown](https://www.geeksforgeeks.org/difference-between-internal-and-external-fragmentation/) of **internal** and **external fragmentations**

#### **Internal Fragmentation**
> **Internal fragmentation** happens when the memory is split into mounted-sized blocks. Whenever a method is requested for the memory, the mounted-sized block is allotted to the method. In the case where the memory allotted to the method is somewhat larger than the memory requested, then the difference between allotted and requested memory is called **internal fragmentation**.

![[Untitled-Diagram-146.png]]
#### **External Fragmentation**
> **External fragmentation** happens when there’s a sufficient quantity of area within the memory to satisfy the memory request of a method. However, the process’s memory request cannot be fulfilled because the memory offered is in a non-contiguous manner.

![[2581.png]]


