---
tags:
  - CPU
  - bus
---

### **Computer System Buses**

![[Без имени-1.png|342x251]]

#### **Definitions**
A **system bus** is a single computer bus that connects the major components of a computer system
#### **There are 3 types of buses in system bus:**
- [[#1. Address Bus]]
- [[#2. Data Bus]]
- [[#3. Control Bus]]

---
#### **1. Address Bus**
- **Function**: 
  - Carries memory/IO addresses from CPU to other components
  - Unidirectional (one-way communication: CPU → Memory/IO)
  - Based on width of a address bus we can determine the capacity of a main
memory
  - Larger width → More main memory capacity supported
---
#### **2. Data Bus**
- **Function**:
  - Transfers actual data between CPU, memory, and I/O devices
  - Bidirectional (two-way data flow)
  - Based on the width of a data bus we can determine the word length of a
**CPU**.
  - Wider bus → Higher performance **CPU** (more data per clock cycle)
  - Based on the word length we can determine the performance of a **CPU**
---
#### **3. Control Bus**
- **Function**:
  - Transmits control/timing signals between components
  - Bidirectional (signals flow both ways)
  - Control signals indicates type of operation.
  - Timing Signals used to synchronize the memory and IO operations with a
CPU clock.

#### **4. Comparative Analysis**
| **Bus Type** | **Direction**  | **Data**         |
| ------------ | -------------- | ---------------- |
| Address      | Unidirectional | Memory addresses |
| Data         | Bidirectional  | Actual data      |
| Control      | Bidirectional  | Control signals  |
