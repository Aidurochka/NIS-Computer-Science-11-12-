---
tags:
  - virtual-machine
  - OS
---

### **Virtual Machines**

#### **1. Core Definitions**
- **Virtual Machine (VM)**: 
  - *Definition*: A software emulation of a physical computer system that executes programs like a real machine.
  - *Purpose*: Runs incompatible software/OS on existing hardware (e.g., running macOS software on a Windows PC).

- **Emulation**:
  - *Definition*: The use of software/device to imitate another program/device’s behavior.
  - *Example*: Running Android OS on a Windows PC via an emulator.

#### **2. Key Components**
| **Term**       | **Definition**                                                                 | **Example**                                |
|----------------|-------------------------------------------------------------------------------|------------------------------------------|
| **Host OS**    | The primary OS controlling physical hardware.                                  | Windows 10 on a laptop.                  |
| **Guest OS**   | The OS running within the virtual machine.                                     | macOS running inside a VM on Windows 10. |
| **Hypervisor** | Software that creates/manages VMs by mapping virtual hardware to physical resources. | VMware, VirtualBox.                      |

#### **3. How Virtual Machines Work**
1. **Setup**: 
   - A hypervisor (e.g., VirtualBox) installs on the **host OS**.
   - Allocates virtualized CPU, RAM, storage, and devices to the VM.
2. **Execution**: 
   - The **guest OS** runs atop the hypervisor, unaware it’s virtualized.
   - Hypervisor translates guest OS commands into host hardware instructions.
3. **Example**: 
   - Windows 10 (host) runs a Linux VM (guest) for software development.

#### **4. Advantages & Disadvantages**
| **Advantages (+)**                                                               | **Disadvantages (–)**                                                    |
| -------------------------------------------------------------------------------- | ------------------------------------------------------------------------ |
| **Cost-Efficient**: No need for extra hardware; runs multiple OS on one machine. | **Performance Overhead**: Simultaneous OS execution slows down the host. |
| **Flexibility**: Switch between OS instantly (e.g., Windows to Linux).           | **Single Point of Failure**: Host OS crash affects all VMs.              |
| **Energy-Saving**: Reduced electricity vs. multiple physical machines.           | **Compatibility Issues**: Some hardware/software may not work in VMs.    |
| **Isolation**: VM crashes don’t affect host OS (unless hypervisor fails).        | **Resource Intensive**: Requires significant RAM/CPU allocation.         |

#### **5. Use Cases**
- **Software Testing**: Run untrusted apps in a sandboxed VM.
- **Cross-Platform Development**: Test software on different OS without dual-booting.
- **Legacy Systems**: Emulate outdated OS (e.g., Windows XP) for old applications.

