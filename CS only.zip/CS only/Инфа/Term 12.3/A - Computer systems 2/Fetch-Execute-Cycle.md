---
tags:
  - CPU
---

## Fetch-execute cycle  
> **Fetch-execute cycle** – the continuous process carried out by the processor when running programs.  

#### **Three steps**
- **Fetch** – the processor fetches the program’s next instruction from memory. The instruction will be stored at a memory address and will contain the instruction in binary code.  
- **Decode** – the processor works out what the binary code at that address means.  
- **Execute** – the processor carries out the instruction which may involve reading an item of data from memory, performing a calculation or writing data back into memory.  
[Detailed explanation](https://youtu.be/jFDMZpkUWCw?si=ZObFU2w1xkYmWb0u)
---

### **Registers in the CPU**  
###### **[detailed explanation](https://youtu.be/jFDMZpkUWCw?si=ZObFU2w1xkYmWb0u)**
- **Program Counter (PC)** – an incrementing counter that keeps track of the memory address of which instruction is to be executed next.  
- **Memory Address Register (MAR)** – the address in main memory that is currently being read or written.  
- **Memory Buffer Register (MBR)** or **Memory Data Register (MDR)** – a two-way register that holds data fetched from memory (and ready for the CPU to process) or data waiting to be stored in memory.  
- **Current Instruction Register (CIR)** – a temporary holding ground for the instruction that has just been fetched from memory.  
- **Status Register (SR)** – contains bits that are set or cleared depending on the result of an instruction. 
- **Accumulator (ACC)** – an internal CPU register used as the default location to store any calculations performed by the arithmetic and logic unit.  

---

### **Factors Affecting CPU Performance**  
 
#### **Full text - a lot of important theory**
- **Word length:** Word size refers to the amount of data that can be handled at one time by the processor. The larger the word size, the greater the amount of data that can be transferred to the CPU in one pass. This is an important factor for the processor performance, as to process an instruction it might well require multiple fetches of data from the main memory. Therefore, being able to pass larger amounts of data to the processor with every pass, the system is likely to carry out instructions faster.  

- **Bus width:** The width of the data bus determines the number of bits that can be transferred to or from in one operation (i.e., at the same time, in one pass). The larger the data bus, the better the processor performance. This is because the greater the width of the data bus, the more data can be transferred between the internal components simultaneously.  

- **Clock speed:** The clock speed of a CPU is the rate at which it can execute instructions, measured in GHz (gigahertz). A higher clock speed generally means that the CPU can execute instructions more quickly, resulting in better performance.  

- **Cache size:** The CPU cache is a small amount of memory that is located on the CPU itself and is used to store frequently accessed data and instructions. A larger cache can improve CPU performance by reducing the amount of time it takes to access frequently used data.  

- **Number of cores:** Modern CPUs often have multiple cores, which allow them to execute multiple instructions simultaneously. CPUs with more cores can generally perform better for tasks that can be parallelized, such as rendering graphics or running multiple applications at once.  

- **Instruction set architecture:** The instruction set architecture (ISA) of a CPU determines the types of instructions it can execute. A more advanced ISA can enable a CPU to perform more complex operations, leading to better performance.  

#### **Table comparison**

| **Factor**                                                      | **Description**                                                      | **Impact on Performance**                                                           |
| --------------------------------------------------------------- | -------------------------------------------------------------------- | ----------------------------------------------------------------------------------- |
| **Bus Width**                                                   | Number of bits transferred simultaneously in one operation           | Wider bus → More data transferred per cycle → Better performance                    |
| **Clock Speed**                                                 | Instruction execution rate (measured in GHz)                         | Higher clock speed → Faster instruction processing                                  |
| **Cache Size**                                                  | On-CPU memory for frequently accessed data/instructions              | Larger cache → Reduced memory access latency → Improved performance                 |
| **Number of Cores**                                             | Independent processing units within CPU                              | More cores → Better parallel task handling (e.g., multitasking, graphics rendering) |
| ***[[CPU architectures\|Instruction Set Architecture (ISA)]]*** | Set of commands the CPU can execute                                  | Advanced ISA → More complex operations possible → Better efficiency                 |
| **Word Length**                                                 | Amount of data handled per operation (bits processed simultaneously) | Larger word size → Fewer memory fetches needed → Faster instruction execution       |