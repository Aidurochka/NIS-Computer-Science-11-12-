---
tags:
  - CPU
  - CPU-architectures
---


### **CPU architectures**


| **Feature**               | **CISC (Complex Instruction Set Computing)**       | **RISC (Reduced Instruction Set Computing)**       |
|---------------------------|--------------------------------------------------|--------------------------------------------------|
| **Instruction Set**       | Complex Instruction Set                         | Reduced Instruction Set                         |
| **Instruction Size**      | Non-fixed size (variable format instructions)   | Fixed-size instructions                         |
| **Instruction Complexity**| Complex instructions (may take multiple cycles) | Simple instructions (combined for complex tasks)|
| **Number of Instructions**| Many instructions and addressing modes          | Limited number of instructions                  |
| **Task Performance**      | Performs complex tasks faster                   | Performs simple tasks faster                    |
| **Code Size**             | Small code sizes                                | Large code sizes                                |
| **Cycles per Second**     | High cycles per second                          | Low cycles per second                           |
| **Processor Design**      | Complicated and expensive                       | Simple design                                   |
| **CPU Components**        | More components on CPU                          | Fewer components on CPU                         |
| **RAM Usage**             | Uses less RAM                                   | Uses more RAM                                   |
| **Heat Production**       | Produces more heat (needs cooling)              | Produces less heat                              |
| **Common Applications**   | Used in PCs                                     | Used in tablets and mobile devices              |
| **Data Movement**         | Memory-to-memory                                | Register-to-register                            |
| **Power Consumption**     | Requires more power                             | Requires less power                             |
| **Register Usage**        | Uses fewer registers                            | Uses more registers                             |
| **Pipelining**            | Cannot use pipelining                           | Uses pipelining                                 |
