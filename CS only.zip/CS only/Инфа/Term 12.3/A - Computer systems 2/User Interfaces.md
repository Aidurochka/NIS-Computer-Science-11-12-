---
tags:
  - user-interfaces
  - interface
---

### **User Interfaces**

#### **1. Graphical User Interface (GUI)**
>  A visual interface that allows users to interact with a computer system using **graphical** elements such as windows, icons, menus and pointers (WIMP).

**Definition:** Visual interface using windows, icons, menus, and pointers (WIMP).

| **Advantages**                                      | **Disadvantages**            |
| --------------------------------------------------- | ---------------------------- |
| Easy for beginners                                  | Requires more disk space     |
| No complex commands to learn                        | Slower for experienced users |
| Easy data exchange (cut/paste, drag/drop)           | Limited OS portability       |
| Multitasking capability                             |                              |
| Accessibility features (screen readers, magnifiers) |                              |
**Examples:** Windows XP/Vista, macOS, Ubuntu

---
#### **2. Command Line Interface (CLI)**
>  **Text-based** interface that allows users to interact with a computer system by typing **commands** into a terminal or shell.

**Definition:** Text-based interface using typed commands

|**ADVANTAGES**|**DISADVANTAGES**|
|---|---| 
|Faster for users who know commands|Confusing for beginners|
|Low memory/processing requirements|Commands must be typed precisely|
|Works with low-resolution monitors|Many commands to memorize|
|Minimal CPU usage||
**Common CLIs:** MS-DOS, Terminal (macOS/Linux), Command Prompt, PowerShell  

---
#### **3. Natural Language Interface (NLI)**
> Type of **computer-human interface** where linguistic phenomena are used for creating, selecting, and modifying data in software applications

**Definition:** Interface using spoken/written human language.

|**Advantages** (+)|**Disadvantages** (-)|
|---|---|
|The user does not need to be trained on how to use the interface|The interface can only respond to programmed commands|
|Suitable for people with disabilities|Very difficult in programming, so it is used when other types of interface are not suitable|
|Allows interaction at a distance|The voice interface may need training as different users have different pronunciations|
**Applications:**  
- Search engines  
- Computer games  
- Document management (semantic analysis)  
**Examples:** Siri, Alexa, Google Assistant  

---

#### **4. Gesture Recognition Interface**
**Definition:** Interface using body movements/touch.

|**Advantages**|**Disadvantages**|
|---|---|
|It is an intuitive and natural way of interaction|Irrelevant objects with hands can mislead the recognition system|
|Recognizes both static and dynamic hand movements|The performance of this system drops as the distance between user and camera increases|
|It has minimal hardware requirements|It still doesn't produce an interface that can replace physical controllers|
|Easily implemented in real-time systems||
**Gesture Types:**  
1. **Navigational** (moving through UI)  
2. **Action** (scrolling, selecting)  
3. **Transform** (resizing/rotating objects)  

---


