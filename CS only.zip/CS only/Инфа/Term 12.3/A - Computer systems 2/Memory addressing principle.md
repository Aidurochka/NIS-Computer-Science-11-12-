---
tags:
  - memory-addressing
  - memory
  - CPU
---
### **Memory Addressing (12.3.4.1)**  

#### **1. Definition of Memory Addressing**  
- **Memory addressing**: The process of identifying the location of a specific piece of data in computer memory.  
- **Addressing Modes**: Rules for interpreting/modifying the address field of an instruction before execution.  

#### **2. Addressing Modes**  

| **Mode**               | **Description**                                                                 | **Example (Assembly Instruction)** |  
|------------------------|-------------------------------------------------------------------------------|----------------------------------|  
| **Direct Addressing**  | Uses the contents of the memory location specified in the operand.             | `LDD 200` → Loads value `20` from address `200` into the accumulator. |  
| **Indirect Addressing**| Uses the contents of the memory location pointed to by the operand.            | `LDI 200` → Loads value `5` (from address `20`, where `200` points to `20`). |  
| **Indexed Addressing** | Adds the index register (IR) value to the operand address to locate data.      | `LDX 200` → If `IR=4`, loads value `17` from address `204` (`200+4`). |  
| **Immediate Addressing**| Uses the operand value directly (no memory fetch).                            | `LDM #200` → Loads literal value `200` into the accumulator. |  
| **Relative Addressing**| Computes the target address as the current address + operand offset.          | `JMR #5` → Jumps to the instruction `5` locations ahead. |  
