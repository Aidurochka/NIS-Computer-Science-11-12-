- [[Declarative and imperative programming languages]]
- [[Expert Systems]]
- [[Program Compilation stages]]

See also [[B - Programming Paradigms 1|Programming Paradigms 1]]