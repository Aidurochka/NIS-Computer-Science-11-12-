# Program Compilation Stages (12.5.1.3 - 12.5.1.6)

- **[[#Stages]]**
- **[[#Supporting Components]]**
- **[[#Key Relationships]]**

---
#### **Compilation Process Overview**
A [[Translators#Compiler|compiler]] transforms source code into machine code through several sequential phases, each converting the program to a different representation.

---
#### **Stages**
There are 6 stages of compilation process:
    **[[#1. Lexical Analysis (Scanning)|1. Lexical Analysis ]]**
    **[[#2. Syntax Analysis (Parsing)|2. Syntax Analysis]]**
    **[[#3. Semantic Analysis**|3. Semantic Analysis]]**
    **[[#4. Intermediate Code Generation]]**
    **[[#5. Code Optimization]]**
    **[[#6. Code Generation]]**

---
#### **1. Lexical Analysis (Scanning)**
- Removes comments and unnecessary whitespace
- Converts keywords, constants, and identifiers into tokens (symbolic representations)
- Example: "int x = 5;" becomes [TYPE:int], [ID:x], [OP:=], [NUM:5]
---
#### **2. Syntax Analysis (Parsing)**
- Verifies tokens follow language grammar rules
- Builds parse tree/abstract syntax tree
- Detects and reports syntax errors (e.g., missing semicolons)
---
#### **3. Semantic Analysis**
- Validates variable declarations and data types
- Checks operation-variable type compatibility
- Ensures program logic follows language semantics
---
#### **4. Intermediate Code Generation**
- Produces platform-independent intermediate representation
- Serves as bridge between high-level and machine code
---
#### **5. Code Optimization**
- Improves efficiency by:
  - Removing redundant code
  - Reordering operations
  - Simplifying expressions
- Goal: **Faster execution** with fewer resources
---
#### **6. Code Generation**
- Converts optimized **intermediate code** to target **machine code**
- Handles:
  - Memory allocation
  - Register assignment
  - Instruction selection
---
#### **Supporting Components**
- **Symbol Table**: Stores identifier attributes (name, type, scope)
- **Error Handler**: Reports errors during all phases

#### **Key Relationships**
Lexical → Syntax → Semantic → Intermediate → Optimization → Generation

```mermaid
flowchart TB
    A[Lexical] --> B[Syntax]
    B --> C[Semantic]
    C --> D[Intermediate]
    D --> E[Optimisation]
    E --> F[Code Generation]
```