# Declarative vs. Imperative Programming (12.5.1.1)

- **[[#Key Definitions**|Definitions]]**
- **[[#Core Differences**|Core Differences]]**
- **[[#Examples**|Examples]]**

---
#### **Key Definitions
- **Imperative (Procedural) Languages**: Programming approach where developers write explicit step-by-step instructions for the computer to execute. 
      **Examples** include C, C++, C#, Pascal, and Java.
- **Declarative Languages**: Programming approach that focuses on describing what the program should achieve rather than specifying how to achieve it. 
      **Examples** include HTML, CSS, SQL, Prolog, and XQuery. 
---
#### **Core Differences**
- **Imperative**: Focuses on **how** to perform tasks (step-by-step commands).
- **Declarative**: Focuses on **what** the outcome should be (result-oriented).

**Simply**
- Imperative - instructions
- Declarative - results

---
#### **Examples**
- **Imperative**: Writing a loop to process each item in a list.
- **Declarative**: Using SQL to query a database without specifying how to retrieve the data.

