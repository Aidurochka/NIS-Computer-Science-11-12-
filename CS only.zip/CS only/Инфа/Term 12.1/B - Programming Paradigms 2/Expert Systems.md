# **Expert Systems (12.5.1.2)**  

- **[[#**Definition**|Definition]]**
- **[[#**Characteristics**|Characteristics]]**
- **[[#**Applications**|Applications]]**
- **[[#**Components**|Components]]**
- **[[#**User Interaction**|User Interaction]]**
- **[[#**Benefits vs. Limitations**|Benefits vs. Limitations]]**


---
#### **Definition**  
> An **Expert System (ES)** is an interactive, reliable computer-based **decision-making** system that uses facts and heuristics[^1] to solve complex problems in specific domains.  

---
#### **Characteristics**  
- Provides the **highest level of expertise** (efficient, accurate, imaginative problem-solving).  
- Has an **adequate response time** (performs faster or equal to a human expert).  
- Maintains **good reliability** (must be as reliable as a human expert, with minimal errors).  
---
#### **Applications**  
1. Loan analysis  
2. Airline and cargo scheduling  
3. Medicine (e.g., **MYCIN, DENDRAL, PXDES, CaDet**)  
4. Stock market trading  
5. Warehouse optimization  
---
#### **Components**  
1. **Knowledge Base**: Stores all expert knowledge (repository of facts).  
2. **Inference Engine**: The "brain" of ES; selects rules and facts to answer queries.  
3. **User Interface**: Allows communication between users and the ES.  

![[image-22.png|500x272]]

---
#### **User Interaction**  

![[image-21.png]]

---
#### **Benefits vs. Limitations**  

| **Benefits**                          | **Limitations**                          |
|---------------------------------------|------------------------------------------|
| 1. Improves decision quality          | 1. High maintenance costs                |
| 2. Maintains a high level of information | 2. Errors in knowledge base lead to wrong decisions |
| 3. Solves complex tasks               | 3. Requires manual updates               |
| 4. Provides fast and accurate answers | 4. Each ES is domain-specific           |

---

[^1]: Heuristics - **mental shortcuts for solving problems in a quick way**
