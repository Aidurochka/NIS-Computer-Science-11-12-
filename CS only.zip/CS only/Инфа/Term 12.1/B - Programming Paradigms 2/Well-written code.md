
1. Comments
2. Tabulations
3. Use of libraries and functions