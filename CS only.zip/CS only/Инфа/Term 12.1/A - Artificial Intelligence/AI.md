---
tags:
  - Information-systems
---

# Artificial Intelligence

- **[[#Definition of Artificial Intelligence (AI)|Definition of Artificial Intelligence]]**
- **[[#**Application Spheres of of AI** (*12.4.3.1*)  |Spheres Where AI is Applied]]**
- **[[#Advantages of AI**|Advantages of AI]]**
- **[[#Disadvantages of AI**|Disadvantages of AI]]**

---

#### **Definition of Artificial Intelligence (AI)**  
> *Artificial intelligence – simulation of human intelligence processes by machines, especially computer systems.*  

---

#### **Application Spheres of of AI** (*12.4.3.1*)  

1. **Industry**  
   - Industrial multitasking robots.  

2. **Education**  
   - AI personalizes educational software by focusing on students’ weak areas and repeating unmastered subjects.  
   - Helps teachers create diverse content to improve teaching and learning.  

3. **Medicine**  
   - Enables faster and better diagnoses.  
   - Uses virtual health assistants and chatbots for patient support.  

4. **Gaming Industry**  
   - Creates responsive, adaptive, and challenging games.  
   - Controls non-player characters (NPCs) via AI algorithms.  
   - Generates dynamic game landscapes/worlds in real-time.  

5. **Society**  
   - Chatbots in banking.  
   - Voice assistants (e.g., Siri, Alexa).  
   - Image/face recognition (e.g., phone unlocks).  
   - Social media recommendations.  

---

#### **Advantages of AI**  
- Excels at detail-oriented jobs.  
- Reduces time for data-heavy tasks.  
- Processes information more efficiently than humans.  
- AI-powered virtual agents are available 24/7.  

#### **Disadvantages of AI**  
- High implementation costs.  
- Requires deep technical expertise.  
- Limited availability of skilled AI programmers.  
- Limited knowledge (only knows what it’s trained on).  

Simply, **efficiency** (pros) vs. **cost** (cons)

---

