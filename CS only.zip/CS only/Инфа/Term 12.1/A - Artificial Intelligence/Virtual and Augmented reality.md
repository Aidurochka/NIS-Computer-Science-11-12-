# Virtual and Augmented Reality (12.4.3.2) 

- **[[#Definitions**|Definitions]]**
- **[[#Equipment Needed for VR**|VR Equipment]]**
- **[[#VR Advantages**|VR Advantages]]**
- **[[#VR Disadvantages**|VR Disadvantages]]**


---
#### **Definitions**  
- **Augmented Reality (AR)**: **an interactive experience that enhances the real world with computer-generated perceptual information**
- **Virtual Reality (VR)**: *"A completely immersive experience that replaces a real-life environment with a simulated one."*  

#### **Key Difference**  
*AR uses a real-world setting while VR is completely virtual.*

---

#### **Equipment Needed for VR**  
- Eye Goggles  
- Special Gloves  
- Headphones  
- Powerful Computer  

*Note*: *"VR requires a headset device, but AR can be accessed with a smartphone."*  

---

#### **VR Advantages**  
1. *"It is safer, as scenarios can be tried out without endangering life."*  
2. *"Potential cost savings as there may be no need to build/use real thing."*  
3. *"Doing difficult or impossible tasks."*  

#### **VR Disadvantages**  
1. *"Issues with motion sickness."*  
2. *"Can cause users to injure themselves if they are not in a large space."*  
3. *"In some cases, users have experienced seizure, so epileptic users must be very cautious."*  
Simply, safety, cost, tasks vs. motion sickness, injuries, seizures


