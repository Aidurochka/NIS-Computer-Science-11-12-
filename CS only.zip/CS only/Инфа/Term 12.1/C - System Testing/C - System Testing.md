---
tags:
  - Testing
  - Test-Data-types
  - Testing-methods
---

# System Testing & Errors (12.1C, 12.5.3.1-12.5.3.6)

- **[[#Purpose of System Testing]]**
- **[[#Test Data Types]]**
- **[[#Testing Methods]]**
- **[[#Types of Errors]]**
- **[[#Exception Handling]]**
- **[[#Test Plan Components]]**


---
#### **Purpose of System Testing**  
- Verify the system meets client requirements  
- Validate the system matches user needs  
- Improve product quality  

---
#### **Test Data Types**  
**[[System Lifecycle models#Test Data Types|Test data types full table]]**

| **Type**      | **Description**                             | **Example**                  |     |
| ------------- | ------------------------------------------- | ---------------------------- | --- |
| **Normal**    | Typical, expected user inputs               | Valid username/password      |     |
| **Extreme**   | Values at program limits (boundary testing) | Minimum/maximum input values |     |
| **Erroneous** | Invalid inputs the program should reject    | Letters in a numeric field   |     |

---
#### **Testing Methods**  
- **Alpha Testing**: In-house testing by developers  
- **Beta Testing**: Limited user trials with feedback collection  
- **Black Box Testing**: Tests functionality *without* viewing code  
- **White Box Testing**: Tests code structure and all execution paths  
- **Dry Run Testing**: Uses trace tables to manually simulate execution  
For the last three, see [[System Lifecycle models#Testing Techniques]]

---
#### **Types of Errors**  
| **Error Type** | **Description**                                                     | **Example**                     |
| -------------- | ------------------------------------------------------------------- | ------------------------------- |
| **Syntax**     | Violates language rules (detected during compilation)               | Missing semicolon, wrong tokens |
| **Logic**      | Program runs but produces incorrect results                         | Wrong formula in calculations   |
| **Runtime**    | Occurs during execution (e.g., infinite loops, connection failures) | `ClassNotFoundException`        |

---
#### **Exception Handling**  
Mechanism to manage runtime errors (e.g., `IOException`, `SQLException`).  
>    Exception handling is **the process of responding to unwanted or unexpected events when a computer program runs**. 
>    Exception handling deals with these events to avoid the program or system crashing, and without this process, exceptions would disrupt the normal operation of a program.

---
#### **Test Plan Components**  
1. **Scope**: What is being tested?  
2. **Test Data**: Normal, extreme, erroneous inputs  
3. **Expected Outcomes**: Correct results for each test case  
