
# Arrays 
## Array
**Definition**: A finite set of indexed elements of the same type, united by a common name.
## 1. One-Dimensional Arrays (11.5.2.1)

```python
# Creating arrays
students = ["Diana", "Abai", "Malika", "Zhanna", "Ruslan"]
marks = [34, 30, 37, 33, 31]

# Accessing elements
print(marks[3])      # Output: 33
print(students[0])   # Output: Diana
print(f"{students[1]} - {marks[1]}")  # Output: Abai - 30
```

## 2. Two-Dimensional Arrays (11.5.2.2)

A **two-dimensional array** (2D array) is an array where each element is
represented by a **one-dimensional array**.
Each element of a **two-dimensional array** has two indices: row number
(**i**) and column number (**j**).


```python
import random

# Create 6x5 grid with nested for loops
grid = []
for i in range(6):
    row = []
    for j in range(5):
        row.append(random.randint(1, 100))
    grid.append(row)
```

## 3. Basic Array Algorithms (11.5.2.3)

### Input Elements
```python
n = 5
arr = []
for i in range(n):
    arr.append(int(input(f"Enter element {i}: ")))
```

### Output Elements
```python
for item in arr:
    print(item)
```

### Sum Calculation
```python
total = sum(arr)  # Built-in function
# Or manually:
total = 0
for num in arr:
    total += num
```

### Count Even Numbers
```python
count = 0
for num in arr:
    if num % 2 == 0:
        count += 1
```

### Output Odd Index Elements
```python
for i in range(len(arr)):
    if i % 2 != 0:
        print(arr[i])
```

## Complete Example
```python
# Create and process student data
students = ["Diana", "Abai", "Malika", "Zhanna", "Ruslan"]
grades = [[85, 90], [78, 82], [95, 88], [91, 87], [76, 80]]

# Calculate averages
for i in range(len(students)):
    avg = sum(grades[i]) / len(grades[i])
    print(f"{students[i]}: {avg:.1f}")
```


# Search Algorithms

#### Linear Search
   Linear search is a simple algorithm.
   It is carried out by comparing the array of elements to match the key
value.
- **Steps**: Compare each element to the key.

- **Pseudocode**:
    FOR i FROM 0 TO array.length - 1
        IF array[i] = key THEN found = True
    ENDFOR
    
| Pros                                    | Cons                           |
| --------------------------------------- | ------------------------------ |
| - Simple implementation of program code | - Slow for large arrays        |
| - Executes quickly for small arrays     | - Needs to check every element |

#### Binary Search
   Binary search divides the array in half and determines the part of the
array that contains the key value.
- **Requirement**: Array must be sorted.

- **Pseudocode**:
    WHILE FIRST <= LAST AND FOUND = FALSE
        MIDDLE = (FIRST + LAST) / 2
        IF ARRAY[MIDDLE] = TARGET THEN FOUND = TRUE
        ELSE IF ARRAY[MIDDLE] > TARGET THEN LAST = MIDDLE - 1
        ELSE FIRST = MIDDLE + 1
    ENDWHILE
    
| Pros                                                                 | Cons                                                                 |
|----------------------------------------------------------------------|----------------------------------------------------------------------|
| ● Faster because it doesn't examine all elements                     | ● Requires the array to be sorted                                   |
| ● Efficient for large arrays                                        | ● More complex algorithm (need to track search range)               |

# Sorting Algorithms

#### Bubble Sort

**How it works:**
1. Go through the array, one value at a time.
2. For each value, compare the value with the next value.
3. If the value is higher than the next one, swap the values so that the highest value comes last.
4. Go through the array as many times as there are values in the array.

- **Pseudocode**:
    FOR i = 0 TO N-2
        FOR j = 0 TO N-i-2
            IF arr[j] > arr[j+1] THEN SWAP(arr[j], arr[j+1])
        ENDFOR
    ENDFOR
    
#### Insertion Sort
   The Insertion Sort algorithm uses one part of the array to hold the sorted values, and the other part of the array to hold values that are not sorted yet.
   
**How it works:**
1. Take the first value from the unsorted part of the array.
2. Move the value into the correct place in the sorted part of the array.
3. Go through the unsorted part of the array again as many times as there are values.

- **Pseudocode**:
    FOR j = 1 TO N-1
        WHILE arr[i] < arr[i-1]
            SWAP(arr[i], arr[i-1])
            IF i > 2 THEN i = i - 1
        ENDWHILE
    ENDFOR
    

### 1.5 Algorithm Efficiency

|Algorithm|Best Case|Average Case|Worst Case|
|---|---|---|---|
|Linear Search|O(1)|O(n)|O(n)|
|Binary Search|O(1)|O(log n)|O(log n)|
|Bubble Sort|O(n)|O(n²)|O(n²)|
|Insertion Sort|O(n)|O(n²)|O(n²)|