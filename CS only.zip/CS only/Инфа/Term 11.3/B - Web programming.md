## 2. Web Programming
### 2.1 HTML Basics
- **Tags**:
  - `<h1>` to `<h6>`: Headings
  - `<p>`: Paragraph
  - `<ul>`/`<ol>`: Lists
  - `<div>`: Division
- **Example**:
  ```html
  <html>
  <body>
      <h1>Heading</h1>
      <p>Paragraph.</p>
  </body>
  </html>
  ```
  <html>
  <body>
      <h1>Heading</h1>
      <p>Paragraph.</p>
  </body>
  </html>


### 2.2 HTML Forms
- **Example**:
  ```html
  <form action="/action_page.php">
      <label for="fname">First name:</label><br>
      <input type="text" id="fname" name="fname"><br>
      <input type="submit" value="Submit">
  </form>
  ```

  <form action="/action_page.php">
      <label for="fname">First name:</label><br>
      <input type="text" id="fname" name="fname"><br>
      <input type="submit" value="Submit">
  </form>


### 2.3 CSS Styling
- **Example**:
  ```html
  <style>
      body { background-color: lightblue; height: 100px; }
      h1 { color: white; text-align: center; width: 100px; }
  </style>
  ```
### Connect to MySQL Database - PHP

```php
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myDB";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";

```
