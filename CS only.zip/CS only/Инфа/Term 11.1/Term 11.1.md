- #### A - [[A - Computer systems]]
- #### B - [[B - Programming Paradigms 1]]
- #### C - [[C - System Lifecycles]]

