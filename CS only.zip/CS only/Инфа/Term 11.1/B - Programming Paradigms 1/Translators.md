---
tags:
  - computer-systems
  - Programming
---

**Translator** - a programming language processor that modifies a computer program from one language to another

Three Different types of [[Software types.canvas|Translators]]:
1) **Assembler**
2) **[[#Compiler|Compiler]]**
3) **[[## Interpreter|Interpreter]]**
---

# Compilers vs Interpreters

## Compiler
**Definition**:  
A translator that converts high-level programming language to low-level programming language. It converts the entire program at once and reports errors after conversion.

**Process**:  
1. Takes entire source code  
2. Translates to machine code  
3. Saves executable to memory  
4. Reports all errors  

### Advantages vs Disadvantages

| Advantages (+)            | Disadvantages (-)           |
| ------------------------- | --------------------------- |
| Faster execution          | Requires more memory        |
| Optimized code            | Additional compilation step |
| More secure               | Not cross-platform          |
| No runtime program needed | Harder to debug             |

---

## Interpreter 
**Definition**:  
A translator that converts high-level programming language to low-level programming language line-by-line, reporting errors immediately during conversion.

**Process**:  
1. Reads one line of source code  
2. Immediately executes or translates it  
3. Reports errors as encountered  

### Advantages vs Disadvantages

| Advantages (+)               | Disadvantages (-)                      |
| ---------------------------- | -------------------------------------- |
| Cross-platform compatibility | Slower execution                       |
| Easier debugging             | Less optimized code                    |
| Lower memory usage           | Less secure                            |
| Immediate execution control  | Requires interpreter on target machine |

---




