---
tags:
  - computer-systems
  - memory
---
- **[[#11.3.4.1 RAM vs ROM|1. RAM vs ROM]]**
- **[[#11.3.4.2 Virtual Memory|2. Virtual memory]]**
- **[[#Cache Memory|3. Cache memory]]**


## 11.3.4.1 RAM vs ROM

> **RAM**: A temporary memory storage where computer stores data it needs to retrieve quickly.
> **ROM**: A memory device that stores information permanently.

| Characteristic   | RAM                     | ROM                     |
| ---------------- | ----------------------- | ----------------------- |
| **Volatility**   | Volatile                | Non-volatile            |
| **Storage**      | Temporary               | Permanent               |
| **Cost**         | More expensive          | Cheaper                 |
| **Speed**        | Faster                  | Slower                  |
| **Modification** | Data can be modified    | Data cannot be modified |
| **Capacity**     | 64MB to 4GB             | Smaller than RAM        |
| **Types**        | Static RAM, Dynamic RAM | PROM, EPROM, EEPROM     |

---

## 11.3.4.2 Virtual Memory

#### **Virtual memory** 
> A method computers use to manage storage space to keep systems running quickly and efficiently.

- If applications need more memory than available, the [[OS]] uses secondary storage to mimic RAM
1. **Pros**:
  - Run more applications simultaneously
  - Run larger applications with less physical **RAM**
  - Avoid needing to purchase additional **RAM**
2. **Cons**:
  - Slower application performance
  - Longer switching times between apps
  - Reduced available hard drive space

---

## Cache Memory
> A high-speed temporary area of memory that stores information the processor is likely to need. This means the processor doesn't have to wait for data and instructions to be fetched from RAM.

The purpose of **cache memory** is to **reduce data access time** from main storage or external sources (disks, networks). By keeping frequently used data readily available:

- Programs run faster
- Reduces waiting time for slower components
- Improves overall system performance
