---
tags:
  - computer-systems
  - OS
  - system-software
---
- **[[#Operating Systems]]**
- **[[#1.1 Purpose and Main Functions]]**
- **[[#1.2 Core OS Tasks]]**
- **[[#12.2.1.2 Single-User vs Multi-User Operating Systems]]**
- **[[#12.2.1.3 Single-Tasking vs Multitasking OS]]**
- **[[#Operating System Types]]**


# **Operating Systems**
>    [[System software]] that manages computer [[Hardware]], software resources, and provides common services for computer programs.

---
#### **1.1 Purpose and Main Functions**
**Resources managed by OS:**
- File System
- Router Devices
- Memory Management
- Networking
- Internet
- Process Management
- Security
- I/O Management
---
#### **1.2 Core OS Tasks**

| Function              | Description                                                               |
| --------------------- | ------------------------------------------------------------------------- |
| Interface             | Provides user interface for easy computer interaction                     |
| CPU Management        | Runs applications and manages process execution                           |
| Multitasking          | Allows multiple applications to run simultaneously                        |
| Memory Management     | Handles program transfers in/out of memory, allocates space, tracks usage |
| Peripheral Management | Controls storage devices (open/close/verify)                              |
| File Organization     | Creates file systems to organize files and directories                    |
| Security              | Implements user accounts and password protection                          |
| Utilities             | Provides hardware management tools                                        |

---
#### **12.2.1.2 Single-User vs Multi-User Operating Systems**

##### **Single-User OS**
Only one user can access the system at a time (e.g., DOS, Windows, Linux).

| Pros (+)                  | Cons (-)                |
| ------------------------- | ----------------------- |
| Serves one user at a time | Limited to single tasks |
| Easy to maintain          | Token trigger issues    |
| Lower damage risk         |                         |
##### **Multi-User OS**
Allows multiple users simultaneously (e.g., Linux, Mac OS X, Windows 10, Unix, Ubuntu).

| Pros (+)                 | Cons (-)                           |
| ------------------------ | ---------------------------------- |
| Highly stable servers    | Expensive services                 |
| Centralized security     | No local user deposits             |
| Remote access capability | Regular maintenance needed         |
| Fault-tolerant network   | Expensive hardware setup           |
|                          | Performance degradation under load |

---

#### **12.2.1.3 Single-Tasking vs Multitasking OS**

- **Single-tasking**: Runs one program at a time (e.g., DOS)
- **Multitasking**: Executes multiple tasks concurrently(Windows)

---
#### **Operating System Types**

##### **There are 3 types of OS**
- **[[#1. Real-Time Operating System (RTOS)]]**
- **[[#2. Network Operating System (NOS)]]**
- **[[#3. Batch Processing System]]**
**[[#Comparison Summary]]**
---
##### **1. Real-Time Operating System (RTOS)**
>    When the computer has to react within a guaranteed time to an input, a real-time operating system (RTOS) is used.

**Key Features:**
- Processes and executes user requests **immediately**
- Must respond to inputs within a **guaranteed time** (predictable response time)
- Speed is less important than **timing reliability**
- Often used for **critical control systems**

**Examples:**
- Airline traffic control systems
- Command and control systems
- Airline reservation systems

**Important Note:** RTOS doesn't have to be fast, just reliably quick enough for its specific application.

---
##### **2. Network Operating System**
>    Software that connects multiple devices and computers on the network and allows them to share resources on the network.

**Key Features:**
- Connects multiple devices and computers on a network
- Enables resource sharing across the network
- Manages network communication and security

**Examples:**
- Microsoft Windows Server 2003
- UNIX
- Linux
- Mac OS X
---
##### **3. Batch Processing Operating System**
>    **OS** that processes large amounts of data in batches. This type of system is typically used by businesses and organizations that need to process large amounts of data quickly and efficiently

>    This method of operation lends itself to jobs with similar inputs, processing, and outputs where **no human intervention** is needed. Jobs are stored in a queue until the computer is ready to deal with them. Often batch processed jobs are done **overnight**.

**Key Features:**
- Processes large amounts of data in **batches**
- Ideal for repetitive jobs with similar inputs, processing, and outputs
- Jobs are stored in a **queue** and processed when ready
- Typically runs **without human intervention**
- Often scheduled for overnight processing

**Examples:**
- Payroll systems
- Bank statement processing
- Large-scale data processing tasks

---
##### **Comparison Summary**
| **Type**         | **Response Time** | **Primary Use**          |
| ---------------- | ----------------- | ------------------------ |
| Real-Time        | Immediate         | Critical control systems |
| Network          | Variable          | Resource sharing         |
| Batch Processing | Delayed           | Large data jobs          |
