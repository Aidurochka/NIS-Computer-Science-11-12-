---
tags:
  - computer-systems
  - software
  - application-software
---
**Application [[Software]]** is software that performs specific tasks for a user.
# 3 categories of [[Software types.canvas|Application software]]:
#### 1. General purpose  
**Definition**:  
Versatile programs designed to perform broad categories of general purpose tasks.
**Key Characteristics**:
- Designed for mass market use
- Highly customizable through settings/plugins
**Examples**:
- Word Processors (Microsoft Word, Google Docs)
- Spreadsheets (Excel, Sheets)
- Presentation Software (PowerPoint, Keynote)
#### 2. Special purpose  
**Definition**:  
Programs focused on executing specific, well-defined tasks.
**Key Characteristics**:
- Narrower scope than general purpose
- Optimized performance for dedicated functions
**Examples**:
- **Web Browsers** (Chrome, Firefox)
  - Tab management, Extension ecosystem, Network protocols handling
- **Media Players** (VLC, Windows Media Player)
  - Codec support, Playback controls, Streaming capabilities
- **Calendar Programs** (Outlook Calendar, Google Calendar)
#### 3. [[Bespoke]] application software 
Software built for a specific user and purpose
   Example: car robot control software / military control software

### Common Examples  
- Microsoft Office suite (Word, Excel, PowerPoint, Outlook).  
- Internet browsers (Chrome, Safari, Firefox).  
- Design tools (Photoshop, CorelDraw, AutoCAD).  



---
