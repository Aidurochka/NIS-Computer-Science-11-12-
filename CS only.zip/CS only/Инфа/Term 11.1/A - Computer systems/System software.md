---
tags:
  - computer-systems
  - software
  - system-software
---

**System software** - software designed to operate the computer [[Hardware]] and to
provide a platform for running [[Application Software]].
### 4 categories of System software:
### Utility Programs:
Programs that perform common system tasks, such as file management, disk cleanup, or file archiving (e.g., file archivers).
- **Examples:** Disk cleanup tools, file archivers (ZIP/RAR), system optimizers.
### **[[Translators]]:**
Software that converts programming language instructions into machine code (0s and 1s). There are three main types:
- **[[Translators#Compiler|Compiler]]** – Translate entire programs at once (e.g., C, C++).
- **Assemblers** – Convert assembly language to machine code.
- **[[Translators#Interpreter|Interpreter]]** – Execute code line-by-line (e.g., Python, JavaScript).
### **Library Programs:**
Pre-written code, data, or resources that can be reused by other programs to **avoid redundancy**.
- **Examples:** Math libraries, graphics libraries (e.g., OpenGL), standard function libraries.
### **Operating System ([[OS]]):**
A set of programs that manage hardware, software, and general computer operations.
- **Functions:** Memory management, process scheduling, file handling, user interface.
- **Examples:** Windows, macOS, Linux, Android.

