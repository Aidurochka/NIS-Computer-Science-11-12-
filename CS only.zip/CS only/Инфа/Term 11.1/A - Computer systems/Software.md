---
tags:
  - computer-systems
  - software
---

**Software** - a program or a set of programs used to manage a computer
### **Two [[Software types.canvas|Software types]] :**
- [[Application Software]]
- [[System software]]

Open-source software is software with source code that anyone can inspect, modify,
and enhance. (Linux)
Closed-source software is software that holds the source code safe and
encrypted. (Windows)