---
tags:
  - computer-systems
---


# Boolean Algebra Laws

## Logical Equivalences

| Name             | AND Form                                    | OR Form                                            |
| ---------------- | ------------------------------------------- | -------------------------------------------------- |
| Identity law     | $A = 1 \cdot A$                             | $A = 0 + A$                                        |
| Null law         | $0 = 0 \cdot A$                             | $1 = 1 + A$                                        |
| Idempotent law   | $A = A \cdot A$                             | $A = A + A$                                        |
| Inverse law      | $0 = A \cdot \overline{A}$                  | $1 = A + \overline{A}$                             |
| Commutative law  | $AB = BA$                                   | $A+B = B+A$                                        |
| Associative law  | $(AB)C = A(BC)$                             | $(A+B)+C = A+(B+C)$                                |
| Distributive law | $A+BC = (A+B)(A+C)$                         | $A(B+C) = AB+AC$                                   |
| Absorption law   | $A = A(A+B)$                                | $A = A+AB$                                         |
| De Morgan's law  | $\overline{AB} = \overline{A}+\overline{B}$ | $\overline{A+B} = \overline{A} \cdot \overline{B}$ |

---

# Logic Gates

| Gate | Operator               |
| ---- | ---------------------- |
| AND  | $A \cdot B$            |
| OR   | $A + B$                |
| NOT  | $\overline{A}$         |
| NAND | $\overline{A \cdot B}$ |
| NOR  | $\overline{A + B}$     |
| XOR  | $A \oplus B$           |

![[gate_AND.png]]
![[gate_OR.png]]
![[gate_NOT.png]]
![[gate_NAND.png]]
![[gate_NOR.png]]
![[gate_XOR.png]]
