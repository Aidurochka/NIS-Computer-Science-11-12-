
- [[Software types.canvas|Software types]] - Canvas 
    - [[Software]]
- [[OS]] 
- [[Von Neumann architecture]] 
- [[Memory]] - types 
- [[Boolean logic]]


