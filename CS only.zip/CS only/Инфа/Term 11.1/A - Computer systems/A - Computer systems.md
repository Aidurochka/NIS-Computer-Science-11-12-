
- [[Software types.canvas|Software types]] - Canvas 
- [[OS]] 
- [[Von Neumann architecture]] 
- [[Memory]] - types 
- [[Boolean logic]]


