
# System Development Life Cycle (SDLC)

## Overview
A series of stages that occur during system creation and maintenance.

## SDLC Stages

### 1. Analysis
- Identify and define project requirements
- Gather client needs and expectations
### 2. Design
- Create detailed software design including:
  - User interface
  - Software architecture
  - Data structures
### 3. Implementation
- Write actual code based on design specifications
### 4. Testing
- Verify software meets requirements
- Three main techniques:

#### Testing Techniques
| Technique     | Description                              | Objective                             |
| ------------- | ---------------------------------------- | ------------------------------------- |
| **Black Box** | Tester has no internal knowledge         | Verify input/output and functionality |
| **White Box** | Tester knows internal structure          | Verify code logic and flow            |
| **Dry Run**   | Simulated execution without running code | Identify early design issues          |

#### Test Data Types

| Type | Description | Example (1-10 integer input) |
|------|-------------|-----------------------------|
| **Normal** | Typical expected data | `5` |
| **Extreme** | Upper/lower limit values | `1`, `10` |
| **Boundary** | Values at range edges:<br>- Valid: `1`, `10`<br>- Invalid: `0`, `11` | |
| **Abnormal** | Clearly invalid data | `"Thirteen"`, `5.7`, `14` |
#### Testing Example
**System Requirement**: Accept only integers 1-10  
**Test Cases**:
- Normal: `5` (accept)
- Boundary: `1`, `10` (accept); `0`, `11` (reject)
- Extreme: `1`, `10` (accept)
- Abnormal: `"Thirteen"`, `5.7`, `14` (reject)

### 5. Evaluation & Maintenance
- Ongoing updates and fixes
- Feature additions
- Documentation updates


---

## Key Concepts
```mermaid
graph TD
    A[SDLC] --> B[1.Analysis]
    A --> C[2.Design]
    A --> D[3.Implementation]
    A --> E[4.Testing]
    A --> F[5.Evaluation]
    E --> G[Black Box]
    E --> H[White Box]
    E --> I[Dry Run]  
    
```


# SDLC Models:
### 1. **[[## 1. Waterfall Model|Waterfall]]**
### 2. **[[## 2. Cyclical Models (Agile/Iterative/Incremental)|Cyclical]]**
### 3. **[[## 3. Spiral Model|Spiral]]**

---

## 1. Waterfall Model
**Description**:  
A linear, sequential approach where each phase must be completed before the next begins. Often visualized as flowing steadily downward (like a waterfall) through distinct phases.
```mermaid
flowchart LR
    A[Requirements] --> B[Design]
    B --> C[Development]
    C --> D[Testing]
    D --> E[Deployment]
    E --> F[Maintenance]
```

**Best For**:  
Small projects with well-defined, unchanging requirements where thorough documentation is valued over flexibility.

---

## 2. Cyclical Models (Agile/Iterative/Incremental)
**Description**:  
Flexible approaches that deliver software in repeated cycles (iterations). Work is divided into smaller, manageable modules that are developed, tested, and improved in repeated loops.
```mermaid
graph LR
    A[Requirement] --> B[Design]
    B --> C[Implement]
    C --> D[Test]
    D -->|Repeat| A
```
**Includes**:
- **Agile**: Focuses on customer collaboration and responding to change
- **Iterative**: Builds upon previous versions with refinements
- **Incremental**: Adds functionality piece by piece

**Best For**:  
Projects where requirements are expected to evolve, or when early delivery of partial functionality is valuable.

---

## 3. Spiral Model
**Description**:  
A risk-driven hybrid model combining elements of both iterative development and waterfall. Each cycle (spiral) includes planning, risk analysis, engineering, and evaluation phases.
```mermaid
graph LR
    A[Objectives] --> B[Risk Analysis]
    B --> C[Develop/Test]
    C --> D[Evaluation]
    D -->|Next Spiral| A
```
**Best For**:  
Large, complex, mission-critical projects where risk management is paramount, and budgets allow for extensive prototyping.

---

## Comparative Analysis

### Waterfall
| ➕ Advantages | ➖ Disadvantages |
|--------------|------------------|
| • Simple and easy to manage | • Inflexible to changes |
| • Clear milestones | • Testing occurs too late |
| • Good documentation | • High risk for uncertain projects |

### Cyclical (Agile/Iterative)
| ➕ Advantages                    | ➖ Disadvantages                     |
| ------------------------------- | ----------------------------------- |
| • Early and frequent deliveries | • Requires strong team coordination |
| • Adaptable to changes          | • Less predictable final product    |
| • Continuous improvement        | • Can lack documentation            |

### Spiral
| ➕ Advantages                    | ➖ Disadvantages              |
| ------------------------------- | ---------------------------- |
| • Excellent risk management     | • Complex to implement       |
| • Handles complex projects well | • Potentially endless cycles |

## Model Selection Guide
| Criteria          | Waterfall | Agile   | Spiral    |
| ----------------- | --------- | ------- | --------- |
| **Project Size**  | Small     | Any     | Large     |
| **Flexibility**   | Low       | High    | Medium    |
| **Risk**          | Low       | Medium  | High      |
| **Documentation** | Extensive | Minimal | Extensive |
| **Cost**          | Low       | Medium  | High      |
