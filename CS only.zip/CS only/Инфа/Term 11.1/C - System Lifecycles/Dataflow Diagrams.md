## Guide:
- [[#Definition]]
- [[#DFD Symbols (Gane & Sarson Notation)]]
- [[#DFD Levels]]
# Data Flow Diagrams (DFD)


## Definition
A graphical representation of **data movement** through a process or information system, showing:
- How data enters/leaves the system
- Where data is stored
- How data transforms between processes

## DFD Symbols (Gane & Sarson Notation)

### 1. Process
![[Pasted image 20250331172800.png]]
```mermaid
graph LR
    A[[Process]] -->|Input| B[ ]
    B -->|Output| C[ ]
```
**Function**: Transforms input data flows to output flows  
**Naming Convention**: Verb + Object  
**Examples**:
- `create_exception_report`
- `calculate_discount`
- `validate_input_characters`

### 2. Data Flow
![[Pasted image 20250331172822.png]]
```mermaid
graph LR
    A[ ] -->|Data Flow| B[ ]
```
**Represents**: Persistent data storage  
**Naming Convention**: Noun phrases  
**Examples**:
- `customer_orders`
- `user_profiles`
- `inventory`

### 3. Data Store
![[Pasted image 20250331172831.png]]
```mermaid
graph TD
    A[ ] -->| | B[Datastore]
```
**Characteristics**:
- Represents data at rest
- Labeled with plural nouns (e.g., "Customers", "Orders")
- Shown as open-ended rectangles
- May be duplicated on diagrams

### 4. External Entity (Source/Sink)
![[Pasted image 20250331172842.png]]
```mermaid
graph LR
    A[Entity] -->| | B[ ]
```
**Characteristics**:
- Represents system boundaries
- Sources (providers) and sinks (receivers) of data
- Labeled with noun phrases (e.g., "Customer", "Bank")
**Represents**:
- Data sources (origin)
- Data sinks (destination)  
**Examples**:
- `Customer`
- `Payment Gateway`
- `Inventory System`
## Example DFD (Order System)
```mermaid
flowchart TD
    Customer -->|Order| ProcessOrder[[1.0 Process Order]]
    ProcessOrder -->|Order Details| Orders[(Orders)]
    Orders -->|Order Data| GenerateInvoice[[2.0 Generate Invoice]]
    GenerateInvoice -->|Invoice| Customer
    GenerateInvoice -->|Payment| Bank
```

### Comparison of Notations

| Component       | De Marco & Yourdon | Gane & Sarson      |
|-----------------|--------------------|--------------------|
| **External Entity** | Square/Rectangle   | Square/Rectangle   |
| **Process**        | Circle             | Rounded Rectangle  |
| **Data Store**     | Parallel Lines     | Open Rectangle     |
| **Data Flow**      | Arrow              | Arrow              |

## DFD Levels

### Context Diagram (Level 0)
**Purpose**: Shows system scope and external interactions  
**Components**:
- Single process (the system)
- External entities
- Major data flows

**Example: Basic Calculator**
```mermaid
flowchart TD
    USER -->|Numbers, Operator| CALCULATOR
    CALCULATOR -->|Result| USER
```

### Level 1 DFD
**Characteristics**:
- Breaks down the system process
- Shows major sub-processes
- Includes data stores

**Development Steps**:
1. Identify major data stores
2. List key processing steps
3. Create segments for each step
4. Combine into single diagram
5. Refine organization
6. Number processes (e.g., 1.0, 2.0)


**Example: Basic Calculator**
![[Pasted image 20250402093146.png]]
## Advantages vs Limitations

| Advantages | Limitations |
|------------|-------------|
| ✔ Simplifies user communication | ✖ No process sequencing |
| ✔ No technical knowledge needed | ✖ No timing information |
| ✔ Easy to create/modify | ✖ No frequency details |
| ✔ Clear system boundaries | |

## Practical Example: E-Commerce System

### Context Diagram
```mermaid
flowchart TD
    CUSTOMER -->|Orders| SYSTEM
    SYSTEM -->|Confirmation| CUSTOMER
    WAREHOUSE -->|Inventory Data| SYSTEM
    SYSTEM -->|Shipping Orders| WAREHOUSE
```

### Level 1 Processes
1. `1.0 Process Order`
2. `2.0 Manage Inventory`
3. `3.0 Handle Payment`
4. `4.0 Generate Shipping`





# Flowcharts (11.2.1.8)

## Definition
**Flowcharts** are diagrams that break down tasks or systems into sequential steps, showing how data is:
- Input
- Processed
- Stored
- Output

## Standard Symbols

### Core Symbols(simply)
```mermaid
flowchart TD
    A([Start/End]) --> B[[Process]]
    B --> C{Diamond Decision}
    C -->|Yes| D[/Input/Output/]
    C -->|No| E[("Delay")]
    D --> F[(Data Storage)]
```
![[Pasted image 20250331174512.png]] - Data Storage

![[Pasted image 20250402183608.png]] 
## Example: Order Processing
```mermaid
flowchart TD
    A([Start]) --> B[/"Receive Order (Input)"/]
    B --> C{"Valid Order?"}
    C -->|Yes| D[[Process Payment]]
    C -->|No| E[/"Send Rejection Email"/]
    D --> F[(Save to Orders DB)]
    F --> G[[Generate Invoice]]
    G --> H["Delay: Wait for Payment"]
    H --> I{"Payment Received?"}
    I -->|Yes| J[[Ship Order]]
    I -->|No| K[/"Send Payment Reminder"/]
    J --> L[/"Email Tracking Info"/]
    L --> M([End])
    K --> H
```

---
tags: [flowcharts, algorithm-visualization]
---

## Flowchart Pros and Cons

| Advantages (+) | Disadvantages (-) |
|---------------|-------------------|
| ✅ Excellent for visualizing algorithm sequence | ❌ Time-consuming to draw precise shapes |
| ✅ Clearly displays decision points, inputs, and outputs | ❌ Difficult to modify after completion |
| ✅ Provides immediate visual complexity assessment | ❌ Becomes unwieldy for very large/complex algorithms |
| ✅ Universal understanding across technical levels | ❌ Limited space for detailed annotations |
| ✅ Helps identify logic errors visually | ❌ Manual maintenance challenges |

