---
tags: [data-analysis, data-collection, research-methods]
---

# Data Collection Methods 

## Standard Collection Techniques

### 1. Surveys & Questionnaires
**Characteristics**:
- Structured format with predefined questions
- Can be distributed widely

| Advantages | Disadvantages |
|------------|---------------|
| ✅ Less time-consuming | ❌ Limited to closed-ended questions |
| ✅ Easy to analyze statistically | ❌ Requires careful sample selection |
| ✅ Cost-effective for large groups | ❌ May lack depth |

**Best For**: Quantitative research with large populations

---

### 2. Interviews
**Types**:
- Structured
- Semi-structured
- Unstructured

| Advantages                          | Disadvantages                   |
| ----------------------------------- | ------------------------------- |
| ✅ Allows clarification/probing      | ❌ Time-intensive                |
| ✅ Gathers in-depth qualitative data | ❌ Smaller sample sizes          |
| ✅ Captures nuanced perspectives     | ❌ Requires skilled interviewers |

**Best For**: Exploratory research, sensitive topics

---

### 3. Direct Observation
**Approaches**:
- Participant observation
- Non-participant observation

| Advantages                      | Disadvantages            |
| ------------------------------- | ------------------------ |
| ✅ Natural, unstructured setting | ❌ Slow data collection   |
| ✅ No special equipment needed   | ❌ Observer bias possible |
| ✅ Captures actual behavior      | ❌ May miss rare events   |


**Best For**: Behavioral studies, contextual analysis

---

### 4. Other Methods
- **Focus Groups**: Group discussions (6-10 participants)
- **Key Informant Interviews**: Experts/stakeholders
- **Community Meetings**: Public forums
- **MSC Stories**: Most Significant Change narratives

## Method Selection Guide

```mermaid
flowchart LR
    A[Research Goal] --> B{Quantitative data?}
    B -->|Yes| C[Surveys]
    B -->|No| D{Need depth?}
    D -->|Yes| E[Interviews]
    D -->|No| F[Observation]
    E --> G[Individual]
    E --> H[Group/Focus]
```