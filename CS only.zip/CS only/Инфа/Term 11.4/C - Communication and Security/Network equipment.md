---
tags:
  - Network-Devices
  - Hub
  - Switch
  - Bridge
  - Modem
  - NIC
  - Router
  - Repeater
  - Gateaway
---
# Network Connectivity Devices

- There are 8 types of Network Devices:
    [[#1. Hub]]
    [[#2. Switch - Smart Hub|2. Switch]]
    [[#3. Bridge]]
    [[#4. Modem]]
    [[#5. Network Adapter (NIC)]]
    [[#6. Router]]
    [[#7. Repeater]]
    [[#8. Gateway]]
[[#Comparative Summary]]
[[#More info]]

---
## 1. Hub
>    A **hub** is a simple networking device that connects multiple devices, such as computers, printers, and servers to form a [[LAN vs WAN|LAN (click)]]. 

![[image-3.png|302x170]]
- **Function**: Basic device connecting multiple computers to form a LAN  
- **Operation**:  
  - Broadcasts data to ALL connected devices (unintelligent flooding)  
  - Amplifies signal
- **Limitations**:  
  - Causes unnecessary network traffic (congestions)
  - Security risk (all devices see all traffic)  
  - Obsolete in modern networks  

---

## 2. Switch - Smart Hub

>    A **switch** is a networking device that connects multiple devices within a **LAN** and forwards data packets between them. 

![[image-4.png|321x168]]
- **Advanced Function**:  
  - Reads [[Packet routing#**MAC Adresses**|MAC (click)]] addresses (Layer 2 device)  
  - Forwards frames ONLY to target device(Filtering)
- **Benefits**:  
  - Reduces network congestion


---

## 3. Bridge  
>    A **bridge** is a networking device that connects multiple network segments together, allowing devices within each segment to communicate with one another

![[image-9.png|246x174]]

- **Purpose**: Connects two LAN segments  
- **Key Feature**:  
  - Maintains MAC address **table** per port  
  - **Filters** traffic between segments  

> *Comparison*: While switches have hundreds of ports, bridges usually have 2-4 ports for segment interconnection.

---

## 4. Modem  
>  **Modem** is also known as **modulator/demodulator** is a network device that is used to convert digital signal into analog signals of different frequencies and transmits these signals to a modem at the receiving location.

![[image-10.png]]
- **Name Meaning**: MOdulator/DEModulator  
- **Core Functions**:  
  - DAC (Digital to Analog) for transmission  
  - ADC (Analog to Digital) for reception  

---

## 5. Network Adapter (NIC)  
> **NIC** or **network interface card** is a network adapter that is used to connect the computer to the network. It is installed in the computer to establish a [LAN](https://www.geeksforgeeks.org/lan-full-form/).  It has a unique ID that is written on the chip.

![[image-11.png|277x156]]
- **Roles**:  
  - Provides physical network connection  
  - Assigns unique [[Packet routing#**1. Definition of MAC Addresses**|MAC (click)]] address  

---

## 6. Router  
> A **router** is a device, similar to a switch, that routes data packets based on their **IP addresses**. It operates primarily at the Network Layer.
> **Routers** typically connect **LANs** and **WANs** and maintain a dynamically updated routing table, which they use to make decisions about forwarding data packets.

![[image-15.png|270x284]]

- **Layer 3 Operation**:  
  - Routes packets based on IP addresses  
  - Connects different networks (LAN/WAN)  
- **Key Features**:  
  - Maintains routing tables  
  - Implements NAT for internet access  
  - Provides basic firewall protection  


---

## 7. Repeater  
> A **repeater** is a network device that amplifies a signal, allowing it to travel longer distances without losing quality.

![[image-16.png]]

- **Simple Function**: Signal amplification 
- **Limitation**: Doesn't filter or route traffic  
> *Current Status*: Mostly replaced by switches in wired networks.

---


## 8. Gateway  
> A **gateway** connects different networks and translates packets from one network into a format compatible with another. It manages communication between networks with different protocols, ensuring seamless connectivity.

- **Protocol Translation**:  
  - Connects dissimilar networks  
  - Converts between protocols (e.g., IPv4/IPv6)  

---
## Comparative Summary
| Device  | [[OSI model\|OSI layer (#)]] | Intelligence Level | Modern Relevance |
| ------- | ---------------------------- | ------------------ | ---------------- |
| Hub     | 1                            | None               | Obsolete         |
| Switch  | 2                            | High               | Essential        |
| Router  | 3                            | High               | Essential        |
| Gateway | 4-7                          | Highest            | Niche use        |

---

## More info
- [GeeksforGeeks](https://www.geeksforgeeks.org/network-devices-hub-repeater-bridge-switch-router-gateways/?ref=gcse_outind)
- [Journal - recommend for better understanding](https://www.irjmets.com/uploadedfiles/paper//issue_3_march_2024/50285/final/fin_irjmets1710007962.pdf)
