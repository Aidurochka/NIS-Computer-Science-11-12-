---
tags:
  - Topology
  - Bus-topology
  - Star-topology
  - Mixed-topology
---

# Network Topologies

Three types of Network Topologies:
   [[#1. Star Topology]]
   [[#2. Bus Topology]]
   [[#3. Mixed (Hybrid) Topology]]

[[#Comparison Summary]]

---

#### 1. Star Topology
*Each device connects directly to central hub/switch*
![[star.jpg]]

| Pros                                   | Cons                                 |
| -------------------------------------- | ------------------------------------ |
| Fast connection speed                  | Expensive to set up                  |
| Stable with many users                 | Cable failure disrupts client access |
| Easy fault detection                   | Complex installation                 |
| Easy to add new clients                | Server congestion risk               |
| Single failure only affects one client |                                      |

---

#### 2. Bus Topology 
*Single backbone cable connects all devices*
![[220px-BusNetwork.svg 1.webp]]

| Pros                  | Cons                           |
| --------------------- | ------------------------------ |
| Cheaper than star     | Less secure                    |
| Easier to install     | Slows with more users          |
| Simple to add clients | Main cable failure affects all |
|                       | Difficult fault diagnosis      |

---

#### 3. Mixed (Hybrid) Topology
*Combines multiple topology types*
![[Pasted image 20250404192059.png]]

| Pros                        | Cons                       |
| --------------------------- | -------------------------- |
| Highly flexible             | Complex design             |
| Suitable for large networks | Expensive                  |
| Reliable                    | Challenging installation   |
| Scalable                    | High hardware requirements |
|                             | Cable failure risks        |

---

### Comparison Summary

|Topology|Best For|Example Use Cases|
|---|---|---|
|**Star**|Small to medium networks|Offices, Wi-Fi, home networks|
|**Bus**|Legacy/low-cost setups|Old LANs, industrial control systems|
|**Mixed**|Large, complex networks|Enterprises, ISPs, data centers|