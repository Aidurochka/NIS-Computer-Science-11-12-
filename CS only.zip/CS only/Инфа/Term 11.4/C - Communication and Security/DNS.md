## Domain Name System

**DNS** is a naming database that translates human-readable domain names (e.g., _you.are.gay_) into machine-readable IP addresses (e.g., _206.19.49.154_).

https://youtu.be/UVR9lhUGAyU - best video

![[DNS-lookup-process-.png]]

#### **Key Functions of DNS:**

- **Name Resolution** – Converts domain names to IP addresses.
- **Load Distribution** – Balances traffic across multiple servers (e.g., for large websites).
- **Redirection & Caching** – Improves speed by storing recent lookups locally.

#### **DNS Query Process**
When user visit a website:
1. Device checks **local cache**.
2. If not found, it queries a **recursive resolver** (e.g., your ISP’s DNS).
3. The resolver contacts **root → TLD → authoritative servers** to find the IP.
4. The IP is returned and cached for future use.