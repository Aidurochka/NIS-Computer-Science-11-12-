---
tags:
  - URL
  - Internet
---

**URL** (Universal resource Locator) – address for any resource on the internet.
It is used to identify a resource on the internet either by location.

![[image-17.png|565x298]]