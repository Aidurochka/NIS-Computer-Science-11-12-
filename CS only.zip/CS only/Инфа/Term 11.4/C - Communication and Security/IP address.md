---
tags:
  - IP-Address
  - network
---

### **Understanding IP Address Structure**

An **IP address** consists of **two key parts** that work together to identify devices on a network:

1. **Network Identifier**  
   - The **first portion** of the IP address identifies the network.  
   - Example: In `192.168.123.132`, the network part is **`192.168.123`**.  
   - Represented as **`192.168.123.0`** (host bits set to zero for the network address).  

2. **Host Identifier**  
   - The **last portion** identifies the specific device (host) on that network.  
   - Example: In `192.168.123.132`, the host part is **`.132`**.  
   - Represented as **`0.0.0.132`** (network bits set to zero for the host address).  

3. **Example Breakdown**:  
  - Full IP: `192.168.123.132`  
  - Network: `192.168.123.0`  
  - Host: `0.0.0.132`  

