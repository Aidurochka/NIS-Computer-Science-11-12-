---
tags:
  - Client-Server
---


### **Client-Server Model Overview**  

The **client-server model** is a network architecture where:  
- **Server**: A powerful central computer (or program) that provides services, resources, or data.  
- **Client**: Devices or applications that request and use services from the server.  

**Example**:  
- A **web server** (e.g., Apache) hosts a website, while **clients** (e.g., browsers like Chrome) request and display the site.  

---

### **Pros of Client-Server Model**  

1. **Centralized Management**  
   - Easier to update, secure, and back up data on the server.  
2. **Scalability**  
   - Servers can handle multiple clients simultaneously (e.g., cloud services).  
3. **Resource Efficiency**  
   - Clients don’t need high processing power; the server does the heavy lifting.  
4. **Security**  
   - Access controls and encryption are easier to enforce centrally.  

---

### **Cons of Client-Server Model**  

1. **Single Point of Failure**  
   - If the server crashes, clients lose access to services.  
2. **Network Dependency**  
   - Requires stable connectivity; offline operation is limited.  
3. **Cost & Maintenance**  
   - Servers are expensive to set up and maintain.  
4. **Performance Bottlenecks**  
   - Heavy traffic can overload the server, slowing responses.  

---

### **Visualization**  
![[image-20.png|589x361]]```
