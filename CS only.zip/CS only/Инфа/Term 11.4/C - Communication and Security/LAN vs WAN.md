
# Network Types
1.  **LAN (Local Area Network)**: 
> A collection of devices connected together in one physical location, such as a building, office, or home.
- Covers small geographical area (e.g., one building)
2. **WAN (Wide Area Network)**:
> a large network of information that is not tied to a single location
- Covers large geographical distance