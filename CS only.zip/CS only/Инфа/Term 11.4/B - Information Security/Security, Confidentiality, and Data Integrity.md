
## 11.4B Information Security

#### Security, Confidentiality, and Data Integrity
##### 1. **Data Integrity**: 
> A requirement for data to be valid, accurate, and consistent.  

  - **[[Validation and verification#Verification| Verification]]**: Ensures the data is actually the data you want.  
  - **[[Validation and verification#Validation| Validation]]**: Ensures the correct type of data is entered.  
##### 2. **Data Privacy**
> A requirement for data to be available only to **authorized** users.  
##### 3. **Data Security**
> A requirement for data to be recoverable if lost or corrupted.  

#### **Threats to system security**:  
- Internal mismanagement  
- Natural disasters  
- Unauthorized intrusion by individuals  
- Malicious software  

#### **Methods to keep data secure** - [[Security methods]]: 
- Regular [[]] of files  
- Anti-virus software for virus protection  
- Password systems  
- Safe storage of important files on removable disks  
- Restricted access to computer areas (e.g., ID cards, magnetic swipe cards)  
- Logging off or turning terminals off when not in use  
- Write-protecting files to avoid accidental deletion  
- Data encryption to make data unreadable without authorization  

