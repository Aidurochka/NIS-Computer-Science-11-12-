
### Validation and Verification
#### Validation
- **Validation**: A check performed by a program to ensure entered data is reasonable (but cannot guarantee correctness).
####  Verification 
- **Verification**: Ensures the entered data exactly matches the original source.

---

#### Validation Types
| Type          | How It Works                                  | Example Usage                          |
|---------------|---------------------------------------------|---------------------------------------|
| **Check digit** | Last digit(s) validate other digits         | Barcode scanners in stores            |
| **Format check** | Verifies data format                        | NI number: `LL 99 99 99 L`            |
| **Length check** | Ensures correct data length                 | 6-character password requirement      |
| **Lookup table** | Compares against acceptable values         | Validating days of the week (1-7)     |
| **Presence check** | Confirms field isn't empty                 | Mandatory database key fields         |
| **Range check** | Validates value falls within range          | Work hours (0 < hours < 50)           |
| **Spell check** | Matches words against dictionary            | Word processors                       |

---

#### Verification Methods
1. **Double Entry**  
   - Data entered twice and compared  
   - *Drawback*: Doubles workload and costs  

2. **Proofreading**  
   - Manual comparison with source documents  
   - *Drawback*: Time-consuming and expensive
