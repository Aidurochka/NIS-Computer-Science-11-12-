
### Blockchain Technology

#### Definition
A **blockchain** is a method of storing data that becomes immutable (unchangeable) once recorded. This feature is particularly valuable for critical data like financial transactions or bank records.

#### Key Components

1. **Distributed Database**  
   - No central server controls the data  
   - Data is replicated across millions of computers worldwide  
   - Enables data notarization as every participant has a copy  

2. **Network of Nodes**  
   - A **node** is any computer connected to the blockchain network  
   - Nodes sync with the network by downloading the entire blockchain  
   - Nodes validate and propagate transactions  

3. **Miners**  
   - Special nodes that process transactions  
   - Receive incentives for their work maintaining the network  

#### Visual Representation
![[Pasted image 20250404150515.png]]