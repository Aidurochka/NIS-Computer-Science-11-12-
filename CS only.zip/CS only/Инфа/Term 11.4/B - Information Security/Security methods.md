
## Security Methods  

### Data Protection Measures  
**Data Backup**: An additional copy of data used for restore and recovery purposes. Backups are often stored on separate drives or servers.  

#### Types of Backup:  
- **Full Backup**: Copies every item of data, creating a complete duplicate.  
- **Incremental Backup**: Only copies data changed since the last full backup.  
- **Differential (Cumulative) Backup**: Saves changes made since the last backup of any kind.  
https://youtu.be/o-83E6levzM?si=hsZWXusvcdLmBSvU - best explanation video
#### Backup Types Comparison

| Backup Type      | Description                                           | Speed   | Restoration Requirements                           | Restoration Time |
| ---------------- | ----------------------------------------------------- | ------- | -------------------------------------------------- | ---------------- |
| **Full**         | All data is backed up.                                | Slowest | Only full backup needed.                           | Fastest          |
| **Incremental**  | Only data changed since last full/incremental backup. | Fastest | Full backup + all incrementals (in correct order). | Longest          |
| **Differential** | Only data changed since last full backup.             | Medium  | Full backup + last differential.                   | Medium           |

**Disk Mirroring (RAID 1)**: Replicates data across two or more disks. Ideal for applications requiring high performance and availability.  

#### Encryption and Access Rights  
**Encryption**: The process of converting data into an unreadable form using an algorithm and key, ensuring only authorized users can decrypt it.  

#### Purposes of Encryption:  
- Verify authentic users.  
- Prevent message alteration.  
- Block unauthorized access to data.  

**Authorization**: Process by which a server determines if the client has permission
to use a resource or access a file.
- Authorized users receive a user ID and password.  
- Permissions are managed by a system administrator.  
- Passwords and encryption safeguard data from unauthorized access.  
