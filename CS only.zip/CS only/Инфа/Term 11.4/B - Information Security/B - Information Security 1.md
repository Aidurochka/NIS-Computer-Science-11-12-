- [[Security, Confidentiality, and Data Integrity]]
   - [[Validation and verification]] 
- [[Security methods]]
- [[Blockchain]]
- [[Ethics and Ownership]]

