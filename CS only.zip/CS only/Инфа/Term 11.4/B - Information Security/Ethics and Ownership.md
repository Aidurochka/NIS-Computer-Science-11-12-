---
tags:
  - data-and-information
  - copyright
---

#### **Ethics and Ownership in Computing**

#### Copyright
**Definition**: Legal ownership controlling the use and distribution of creative works. Applies to all mediums - copying between mediums requires permission.

**Protected Works** (Kazakhstan Civil Code Article 972):
- Literary, dramatic, musical works
- Choreography, pantomime
- Audiovisual works
- Visual arts (painting, sculpture, graphics)
- Applied arts, architecture
- Photographic works
- Maps, plans, scientific illustrations  
- Computer programs

**Copyright Components**:

| Personal Rights     | Material Rights  |
| ------------------- | ---------------- |
| Right of authorship | Reproduction     |
| Right to name       | Distribution     |
| Right to integrity  | Release to light |
| Right to publish    | Other uses       |

#### Software Types
##### Open Source Software
Open Source Software – program in which the source code is available to the
general public for use and/or modification from its original design free of
charge.
##### Closed Source Software
Closed Source Software – programs that are exclusive property of
their developers or publishers, and cannot be copied or distributed without
complying with their licensing agreements.

| **Open Source**             | **Closed Source**   |
| --------------------------- | ------------------- |
| ✅ Free                      | ✅ Guaranteed safety |
| ✅ Customizable              | ✅ Stable support    |
| ✅ Maximum freedom           | ✅ Easy installation |
| ❌ Requires tech skills      | ❌ Expensive         |
| ❌ Unstable support          | ❌ No customization  |
| ❌ No development guarantees | ❌ Minimal freedom   |

#### Copyright Protection Methods
##### 1. **Licensing**: Legal proof of software purchase and usage terms. 

   Provides users with a **paper-based or digital proof** that they have purchased software legally and details what they are allowed to do with the software.
##### 2. **DRM (Digital Rights Management)**: Controls usage of digital content.

   **Access control software** to limit the way in which users can control, use, copy, print or edit digital content that they have bought
#### Cloud Computing
**Definition**: Online storage/services instead of local devices (e.g., Google Drive, Dropbox)

**Advantages**:
- Reliable backups
- Cross-device compatibility
- Cost-effective (no software purchases)
- Device independence
- Automatic updates

**Disadvantages**:
- Requires internet connection
- Potential copyright issues
- Security vulnerabilities
- Limited features vs desktop software
- Storage limitations (vs physical storage)

