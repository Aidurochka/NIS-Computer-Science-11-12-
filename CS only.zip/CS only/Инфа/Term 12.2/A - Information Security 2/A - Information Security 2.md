- [[Data Protection Measures (Security methods 2)]]
- [[Methods of Information Systems Protection]]
- [[Methods of intellectual property protection]] - BS

