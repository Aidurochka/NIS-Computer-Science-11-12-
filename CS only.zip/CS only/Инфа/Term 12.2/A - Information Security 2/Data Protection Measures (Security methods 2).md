---
tags:
  - Security
  - Data-protection
---
### **Data Protection Measures (12.1.2.1 - 12.1.2.2)**  

- **[[#Data Security]]**
- **[[#Data Protection Measure]]**
- **[[#Encryption Types]]**
---
#### **Data Security**: 
> A requirement for data to be recoverable if lost or corrupted.  

---
#### **Key Threats to Data Security**  
- Lost/damaged during system crashes  
- Corrupted due to faulty disks or power failures  
- Accidentally deleted  
- Compromised by computer viruses  
- Hacked by unauthorized users  
- Destroyed by natural disasters  
---
#### **Data Protection Measures**  

| **Measure**                 | **Description**                                                        |
| --------------------------- | ---------------------------------------------------------------------- |
| **Regular Backups**         | Additional copies of data to restore lost/corrupted files              |
| **Anti-Virus Software**     | Detects and removes malicious software                                 |
| **Strong Passwords**        | 8+ characters with uppercase, lowercase, numbers, and symbols          |
| **Logging Off**             | Prevents unauthorized access when not in use                           |
| **Data Encryption**         | Converts plaintext to ciphertext; only decrypted with a key            |
| **Firewalls**               | Hardware/software that filters network traffic based on security rules |
| **Biometrics**              | Uses unique human traits (e.g., fingerprints) for identification       |
| **Disk Mirroring (RAID 1)** | Stores duplicate data on multiple disks for redundancy                 |

---

#### **Encryption Types**  
**[[Encryption#Encryption Types**|Encryption types]]** - more detailed note
- **Symmetric Encryption**: Uses the same key for encryption and decryption.  
- **Asymmetric Encryption**: Uses two different keys, a **public key** for encryption and a **private key** for decryption

---
#### **Authorization & Access Control**  
- Manages user access to computer resources.  
---
#### **Backup vs. Mirroring**  
- **Backup**: Periodic copies of data for recovery.  
- **Disk Mirroring (RAID 1)**: Real-time duplication across disks to prevent data loss.  
[[Data Mirroring]]

---
#### **Firewall Function**  
- Blocks unauthorized traffic between networks/computers.  
- Customizable rules to filter data packets.  
