#### **Licensing** 
> Provides users with paper-based or digital proof that they have purchased software legally and details of what they are allowed to do with the software