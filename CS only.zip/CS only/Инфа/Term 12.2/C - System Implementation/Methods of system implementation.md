---
tags:
  - system-implementation
  - implementation
---
### **System Implementation Methods**

- **[[#Implementation Overview]]**
- **[[#Implementation Methods Comparison]]**
   - **[[#1. Direct Changeover]]**
   - **[[#2. Parallel Running]]**
   - **[[#3. Pilot Running]]**
   - **[[#4. Phased Implementation]]**
- **[[#Key Comparison Points]]**


---
#### **Implementation Overview**

- **Definition**: Stage where actual code, databases, and system components are created and deployed
- **Changeover**: Process of transitioning from old to new system

---
#### **Implementation Methods Comparison**
##### **1. Direct Changeover**
>    There’s a single, fixed point where one system stops being used and the new one becomes live.

| **Advantages**                                      | **Disadvantages**                                    |
| --------------------------------------------------- | ---------------------------------------------------- |
| **Fastest** implementation method                   | Requires complete staff training before installation |
| New system available immediately after installation | Time-consuming data migration to new system          |
| Cost-effective (only pay for one system)            | No fallback option if new system fails               |
| Lower chance of faults (fully tested beforehand)    | Potential catastrophic failure could halt operations |

---
##### **2. Parallel Running**
>    Both the old and the new systems run side-by-side, using live data, so that project managers can compare the efficiency and reliability of the new system. Once they’re satisfied, the old system is taken offline and the new system becomes fully active and utilised across the organisation. 

| **Advantages** | **Disadvantages** |
|---------------|------------------|
| Old system remains as backup | Most expensive implementation method |
| Zero risk of data loss | Double operational costs (two systems) |
| Allows gradual staff training | Requires additional staff resources |
| Excellent for live system testing | Higher electricity/space requirements |
| Enables result comparison between systems | |

---
##### **3. Pilot Running**
>    A small-scale test or trial of a new process, system, or change in a controlled environment before implementing it on a larger scale.

| **Advantages** | **Disadvantages** |
|---------------|------------------|
| Limited impact if system fails | Slow company-wide implementation |
| Easier to manage (smaller scale) | Pilot department risks data loss |
| Gradual department-by-department training | |
| Pilot staff can train others | |
| More affordable than parallel running | |

---
##### **4. Phased Implementation**
>    A staged method whereby one part of the overall system that needs changing is changed. If any problems arise, they are **limited in scope** and therefore **non-critical**. Once the system has been successfully changed in one area, the other areas can follow suit

| **Advantages**                      | **Disadvantages**                        |
| ----------------------------------- | ---------------------------------------- |
| Gradual staff training (per module) | More expensive than direct changeover    |
| Easier error identification         | Lengthy full implementation              |
| Partial system remains available    | Requires separate testing for each phase |
| Reduces overall implementation risk | Only works for modular systems           |

---
#### **Key Comparison Points:**
- **Speed**: Direct > Phased > Pilot > Parallel
- **Safety**: Parallel > Phased > Pilot > Direct
- **Cost**: Parallel > Phased > Pilot > Direct
- **Training**: Phased/Pilot allow gradual learning
