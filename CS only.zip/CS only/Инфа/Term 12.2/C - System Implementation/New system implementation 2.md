---
tags:
  - system-implementation
  - system-maintenance
  - implementation
---
### **System Implementation & Maintenance**

- **[[#System Implementation Plan]]**
- **[[#System Maintenance Types]]**
- **[[#Key Differences ]]**

---
#### **System Implementation Plan**
**Key Components:**
1. **[[Methods of system implementation|Implementation methods]]**
   - Direct changeover, parallel running, pilot running, or phased implementation  
2. **Reason for Method**  
   - Justification based on cost, risk, and organizational needs  
3. **Implementation & Training Dates**  
   - Timeline with brief explanations for each phase  
4. **Training Method**  
   - On-site training, workshops, e-learning, etc.  

---

#### **System Maintenance Types**  

| **Type**       | **Description**                                         | **Example**                                            |
| -------------- | ------------------------------------------------------- | ------------------------------------------------------ |
| **Corrective** | Fixes faults/bugs missed during testing                 | Resolving a system crash caused by a software error    |
| **Adaptive**   | Adjusts system to new conditions (laws, hardware, etc.) | Updating tax calculation software after policy changes |
| **Perfective** | Improves performance without altering functionality     | Optimizing database queries for faster search results  |

---

#### **Key Differences:**  
- **Corrective**: Reactive (fixes errors)  
- **Adaptive**: Proactive (adapts to changes)  
- **Perfective**: Enhances efficiency (user experience unchanged)  

---
