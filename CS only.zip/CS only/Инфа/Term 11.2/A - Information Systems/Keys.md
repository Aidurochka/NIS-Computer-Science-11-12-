
# Database Keys: In-Depth Explanation

## 1. Primary Key
**Definition**: A column (or set of columns) that uniquely identifies each record in a table.

### Characteristics
```mermaid
graph TD
    A[Primary Key] --> B[Uniqueness]
    A --> C[Non-null]
    A --> D[Immutable]
    A --> E[Single per table]
```

**Implementation**:
```sql
CREATE TABLE Students (
    student_id INT PRIMARY KEY,  -- Single-column primary key
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE
);
```


## 2. Foreign Key
**Definition**: A column that creates a relationship between two tables by referencing another table's primary key.

### Relationship Types
```mermaid
erDiagram
    CUSTOMERS ||--o{ ORDERS : "1-to-many"
    COURSES ||--|{ ENROLLMENTS : "1-to-many"
    EMPLOYEES }|--|| DEPARTMENTS : "many-to-1"
```

**Implementation**:
```sql
CREATE TABLE Orders (
    order_id INT PRIMARY KEY,
    customer_id INT NOT NULL,
    order_date DATE,
    CONSTRAINT fk_customer 
        FOREIGN KEY (customer_id) 
        REFERENCES Customers(customer_id)
        ON DELETE CASCADE
);
```



## 3. Composite Key
**Definition**: A primary key made of two or more columns that together are unique.

### When to Use
```mermaid
flowchart TD
    A[Need to uniquely identify] --> B{Natural combination exists?}
    B -->|Yes| C[Use composite key]
    B -->|No| D[Use surrogate key]
```

**Implementation**:
```sql
CREATE TABLE OrderItems (
    order_id INT,
    product_id INT,
    quantity INT,
    PRIMARY KEY (order_id, product_id),  -- Composite PK
    FOREIGN KEY (order_id) REFERENCES Orders(order_id),
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);
```

**Real-World Example**:
- University database: `(student_id, course_code)` for enrollments
- Banking system: `(account_number, transaction_date, sequence_num)`

## 4. Key Comparison Deep Dive

| Aspect          | Primary Key           | Foreign Key                  | Composite Key                    |
| --------------- | --------------------- | ---------------------------- | -------------------------------- |
| **Purpose**     | Unique identification | Establish relationships      | Multi-field uniqueness           |
| **Null Values** | Not allowed           | Allowed (unless constrained) | No component can be null         |
| **Quantity**    | One per table         | Multiple per table           | One per table (as PK)            |
| **Indexing**    | Automatically indexed | Should be indexed            | Automatically indexed            |
| **Example**     | `user_id`             | `order.user_id`              | `(department_id, employee_code)` |

