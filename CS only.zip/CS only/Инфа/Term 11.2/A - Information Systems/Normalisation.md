
# Database Normalization (11.4.1.7)

## Definition
A systematic technique for organizing database tables to:
- Eliminate data redundancy
- Improve data integrity
- Simplify database maintenance
- Decrease potential errors

## Normal Forms Overview
```mermaid
graph TD
    A[UNF] -->|1NF| B[First Normal Form]
    B -->|2NF| C[Second Normal Form]
    C -->|3NF| D[Third Normal Form]
    D -->|BCNF| E[Boyce-Codd NF]
```

## 1. First Normal Form (1NF)
### Requirements
- **Atomic values**: Each column contains single, indivisible values
- **Unique column names**: No duplicate column names
- **No repeating groups**: Each row must be unique
- **Defined data types**: Each column has a specific type

### Example Transformation
**Before 1NF** (UNF):

| StudentID | Courses         |
|-----------|-----------------|
| 101       | Math, Science   |
| 102       | History         |

**After 1NF**:

| StudentID | Course   |
|-----------|----------|
| 101       | Math     |
| 101       | Science  |
| 102       | History  |

## 2. Second Normal Form (2NF)
### Requirements
- Must satisfy 1NF
- **No partial dependencies**: All non-key attributes depend on the entire primary key (simply, atrribute is in wrong table).

### Example Scenario
**Violation** (in a `StudentCourses` table):
- Composite PK: `(StudentID, CourseID)`
- Attribute `InstructorName` depends only on `CourseID` (partial dependency)

**Solution**:
- Split into two tables:
  1. `Enrollments(StudentID, CourseID)`
  2. `Courses(CourseID, InstructorName)`

## 3. Third Normal Form (3NF)
### Requirements
- Must satisfy 2NF
- **No transitive dependencies**: Non-key attributes shouldn't depend on other non-key attributes

### Example Scenario
**Violation** (in `Students` table):
- `StudentID` → `DormID` → `DormFee` (transitive dependency)

**Solution**:
- Split into:
  1. `Students(StudentID, Name, DormID)`
  2. `Dorms(DormID, DormFee)`

## Practical Example: E-Commerce Database
### Unnormalized
| OrderID | Customer | Items                          | Discount |
|---------|----------|--------------------------------|----------|
| 1001    | John Doe | Pen, Notebook, Eraser          | 10%      |

### 3NF Normalized Structure
```mermaid
erDiagram
    CUSTOMERS ||--o{ ORDERS : places
    ORDERS ||--|{ ORDER_ITEMS : contains
    PRODUCTS ||--o{ ORDER_ITEMS : referenced
    CUSTOMERS {
        int CustomerID PK
        string Name
    }
    ORDERS {
        int OrderID PK
        int CustomerID FK
        date OrderDate
    }
    ORDER_ITEMS {
        int OrderID FK
        int ProductID FK
        int Quantity
    }
    PRODUCTS {
        int ProductID PK
        string Name
        decimal Price
    }
```

## Benefits of 3NF
- **Reduced data duplication**
- **Improved consistency** (no update anomalies)
- **Simpler queries**
- **Better storage efficiency**
