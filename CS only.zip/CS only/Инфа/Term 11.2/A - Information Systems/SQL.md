

## 1. SQL Overview
**Structured Query Language (SQL)**: A specialized programming language for manipulating databases.

**Query (запросик)**: A search or sort operation that retrieves specific data to a question.

## 2. Data Definition Language (DDL)
Used to create and modify database structures; to define which attributes belong in
which table. It also allows you to create users and grant access rights to users.

### DDL Commands
| Command  | Description                              | Example                                               |
| -------- | ---------------------------------------- | ----------------------------------------------------- |
| `CREATE` | Creates database objects with attributes | `CREATE TABLE employees (id INT, name VARCHAR(100));` |
| `ALTER`  | Modifies existing structures             | `ALTER TABLE employees ADD COLUMN age INT;`           |
| `DROP`   | Removes database objects                 | `DROP TABLE temp_data;`                               |

⚠️ **Warning**: `DROP TABLE` permanently deletes all data in the table.

### CREATE TABLE Syntax
```sql
CREATE TABLE table_name (
    column1 datatype [constraints],
    column2 datatype [constraints],
    ...
);
```

### ALTER TABLE Operations
```sql
-- Add column
ALTER TABLE employees ADD COLUMN email VARCHAR(255);

-- Drop column
ALTER TABLE employees DROP COLUMN phone_number;

-- Modify column
ALTER TABLE employees ALTER COLUMN name VARCHAR(150);
```

## 3. Data Manipulation Language (DML)
Used to work with data within tables; to retrieve, update, insert and delete data in a database.

### DML Commands
| Command  | Description      | Example                                             |
| -------- | ---------------- | --------------------------------------------------- |
| `INSERT` | Adds new records | `INSERT INTO customers VALUES (1, 'John', 'Doe');`  |
| `SELECT` | Retrieves data   | `SELECT * FROM products WHERE price > 100;`         |
| `UPDATE` | Modifies records | `UPDATE accounts SET balance = 500 WHERE id = 101;` |
| `DELETE` | Removes records  | `DELETE FROM orders WHERE status = 'cancelled';`    |

### Detailed Examples

**INSERT**:
```sql
INSERT INTO customers (id, first_name, last_name)
VALUES (101, 'Alice', 'Smith');
```

**SELECT**:
```sql
-- Basic selection
SELECT product_name, price FROM products;

-- With sorting
SELECT * FROM employees ORDER BY last_name ASC;

-- SELECT * takes whole row/tuple
```
**UPDATE**:
```sql
UPDATE inventory
SET quantity = quantity - 1
WHERE product_id = 500;
```

**DELETE**:
```sql
-- Conditional deletion
DELETE FROM log_entries WHERE entry_date < '2023-01-01';

-- Full table clearance
DELETE FROM temp_data;
```

## 4. Data Dictionary
**Definition**: A comprehensive list of all data elements in the system.

**Contents**:
- Field names
- Data types
- Length/size
- Validation rules
- Descriptions

**Example Structure**:

| Field Name | Data Type | Length | Required | Description       |
| ---------- | --------- | ------ | -------- | ----------------- |
| student_id | INT       | 4      | Yes      | Unique identifier |
| last_name  | VARCHAR   | 50     | Yes      | Student surname   |
| gpa        | DECIMAL   | (3,2)  | No       | 0.0-4.0 scale     |

## 5. Practical Examples

### Complete Table Creation
```sql
CREATE TABLE students (
    student_id INT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    enrollment_date DATE DEFAULT CURRENT_DATE,
    gpa DECIMAL(3,2) 
);
```

