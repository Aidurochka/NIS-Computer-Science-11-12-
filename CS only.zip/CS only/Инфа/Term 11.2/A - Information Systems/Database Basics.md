
# Relational Database Fundamentals 

## 1. Database Basics 
**Definition**: A structured collection of related data.

### Database Types
1. Hierarchical
2. Network
3. **Relational** (most common)
4. Object-oriented

### Relational Database Features

```mermaid
graph LR
    A[Tables] --> B[Relationships]
    B --> C[Data Integrity]
    C --> D[Query Capability]
```

#### **Database management System (DBMS)** is a program that enables users to create and maintain a database.
## 2. DBMS/RDBMS
**DBMS Functions**:
- 🔒 Security control
- ✔ Data integrity maintenance
- 💾 Backup/recovery
- 🔄 Redundancy control
- 🔍 Query language (SQL)

**Popular RDBMS**:
- MySQL
- Oracle
- SQL Server
- PostgreSQL
- SQLite

## 3. [[Keys|Keys]] Terminology

| Term                                                | Definition                         | Example                 |
| --------------------------------------------------- | ---------------------------------- | ----------------------- |
| [[Entity-Relationship Diagrams#1. Entity\| Entity]] | Object being stored                | `Customer`              |
| **Attribute**                                       | Characteristic (field)             | `CustomerName`          |
| **Table**                                           | Entity implementation              | `Customers`             |
| **Tuple**                                           | Single row/record                  | `(101, 'John Doe')`     |
| **Index**                                           | Performance optimization structure | `CREATE INDEX idx_name` |


## 4. Database [[Keys|Keys (click here)]]
### Key Types Comparison
| Key Type                                     | Purpose                        | Example                |
| -------------------------------------------- | ------------------------------ | ---------------------- |
| **[[Keys#1. Primary Key\|Primary Key]]**     | Unique row identifier          | `CustomerID`           |
| **[[Keys#2. Foreign Key\|Foreign Key]]**     | Links tables                   | `Order.CustomerID`     |
| **[[Keys#3. Composite Key\|Composite Key]]** | Multi-column unique identifier | `(OrderID, ProductID)` |
Primary(PK) and Foreign(FK) Key
https://www.youtube.com/watch?v=B5r8CcTUs5Y&pp=ygUQa2V5cyBpbiBkYXRhYmFzZQ%3D%3D

PK, FK, Composite Key(CK)
https://youtu.be/8wUUMOKAK-c?si=9KX7L5kM9_I1jmYd



**Example Schema**:
```sql
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    Name VARCHAR(100),
    Address VARCHAR(200)
);

CREATE TABLE Orders (
    OrderID INT PRIMARY KEY,
    CustomerID INT FOREIGN KEY REFERENCES Customers(CustomerID),
    OrderDate DATE
);
```

## 5. Data Types 

### 1. Numeric Types

| Data Type      | Description                     | Range (Signed)                  | Range (Unsigned)   | Storage | When to Use                         |
| -------------- | ------------------------------- | ------------------------------- | ------------------ | ------- | ----------------------------------- |
| `INT`          | Whole numbers                   | -2,147,483,648 to 2,147,483,647 | 0 to 4,294,967,295 | 4 bytes | Primary keys, counters              |
| `FLOAT`        | Single-precision floating point | ±1.18E-38 to ±3.40E+38          | N/A                | 4 bytes | Scientific data, approximate values |
| `DOUBLE`       | Double-precision floating point | ±2.23E-308 to ±1.79E+308        | N/A                | 8 bytes | High-precision calculations         |
| `DECIMAL(M,D)` | Fixed-point (exact) numbers     | Depends on M and D              | N/A                | Varies  | Financial data, exact calculations  |

*Where M = total digits, D = decimal places*

### 2. String Types

| Data Type    | Description            | Max Length   | Storage                | When to Use                      |
| ------------ | ---------------------- | ------------ | ---------------------- | -------------------------------- |
| `CHAR(n)`    | Fixed-length string    | 255 chars    | n bytes                | Codes (e.g., ISO country codes)  |
| `VARCHAR(n)` | Variable-length string | 65,535 chars | String length + 1 byte | Names, addresses, most text data |

### 3. Date/Time Types

| Data Type    | Format                  | Storage  | When to Use                          |
|--------------|-------------------------|----------|--------------------------------------|
| `DATE`       | YYYY-MM-DD              | 3 bytes  | Birthdays, events                    |
| `DATETIME`   | YYYY-MM-DD HH:MM:SS     | 8 bytes  | Timestamps, log entries              |
| `TIME`       | HH:MM:SS                | 3 bytes  | Durations, time intervals            |


