Here's a comprehensive Obsidian note on Entity-Relationship Diagrams (ERDs) with enhanced explanations and visual examples:

# Entity-Relationship Diagrams


# https://youtu.be/GFQaEYEc8_8 

## Core Concepts

### 1. Entity
**Definition**: A distinct object about which data is stored  
**Notation**:  
```mermaid
erDiagram
    CUSTOMER {
        int customer_id PK
        string name
        string email
    }
```

### 2. Relationship
**Definition**: A meaningful connection between entities  

## Relationship Types Explained

### 1. One-to-One (1:1)
**Example**: User ↔ UserProfile  
```mermaid
erDiagram
    USER ||--|| USER_PROFILE : "has"
```

**Characteristics**:
- Rare in practice
- Often indicates design opportunity for consolidation
- Example: `Employee ↔ CompanyCar` (one car assigned to one employee)

### 2. One-to-Many (1:N)
**Example**: Department ↔ Employees  
```mermaid
erDiagram
    DEPARTMENT ||--o{ EMPLOYEE : "employs"
```

**Characteristics**:
- Most common relationship type
- Foreign key goes on the "many" side
- Example: `BlogPost ↔ Comments`

### 3. Many-to-Many (M:N)
**Example**: Students ↔ Courses  
```mermaid
erDiagram
    STUDENT }|--|{ COURSE : "takes"
```

**Implementation**:
- Requires junction/associative table
- Example schema: 
  ```sql
  CREATE TABLE StudentCourses (
      student_id INT REFERENCES Students(id),
      course_id INT REFERENCES Courses(id),
      enrollment_date DATE,
      PRIMARY KEY (student_id, course_id)
  );
  ```


## Practical ERD Example: Library System
```mermaid
erDiagram
    BOOK ||--o{ BOOK_COPY : "has"
    BOOK {
        int isbn PK
        string title
        int author_id FK
    }
    AUTHOR ||--o{ BOOK : "wrote"
    MEMBER }|--|{ BOOK_COPY : "borrows"
    BOOK_COPY {
        int copy_id PK
        int isbn FK
        string status
    }
```



# Many-to-Many Relationship Implementation

## Complete Database Schema Example

### 1. Entity Tables
```sql
-- Students entity
CREATE TABLE Students (
    student_id INT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE,
    enrollment_year INT
);

-- Courses entity
CREATE TABLE Courses (
    course_id INT PRIMARY KEY,
    course_code VARCHAR(10) UNIQUE,
    title VARCHAR(100) NOT NULL,
    credits INT CHECK (credits > 0),
    department VARCHAR(50)
);
```

### 2. Junction Table (StudentCourses)
```sql
CREATE TABLE StudentCourses (
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    enrollment_date DATE NOT NULL DEFAULT CURRENT_DATE,
    semester VARCHAR(20),
    grade CHAR(2),
    
    -- Composite primary key
    PRIMARY KEY (student_id, course_id),
    
    -- Foreign key constraints
    CONSTRAINT fk_student
        FOREIGN KEY (student_id) 
        REFERENCES Students(student_id)
        ON DELETE CASCADE,
    
    CONSTRAINT fk_course
        FOREIGN KEY (course_id) 
        REFERENCES Courses(course_id)
        ON DELETE RESTRICT,
    
    -- Additional constraints
    CONSTRAINT chk_grade 
        CHECK (grade IN ('A', 'B', 'C', 'D', 'F', 'I', 'W'))
);
```

## Visual ERD Representation
```mermaid
erDiagram
    STUDENTS ||--o{ STUDENT_COURSES : "enrolls in"
    COURSES ||--o{ STUDENT_COURSES : "offered as"
    STUDENTS {
        int student_id PK
        string first_name
        string last_name
        string email
        int enrollment_year
    }
    COURSES {
        int course_id PK
        string course_code
        string title
        int credits
        string department
    }
    STUDENT_COURSES {
        int student_id FK
        int course_id FK
        date enrollment_date
        string semester
        char grade
    }
```


