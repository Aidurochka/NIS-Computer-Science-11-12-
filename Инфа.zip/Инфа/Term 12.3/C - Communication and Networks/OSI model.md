---
tags:
  - OSI
  - network
  - data-transmission
---

### **Definition**
> The **OSI** (Open Systems Interconnection) network model is a theoretical framework that outlines the functions of a communication system

### **OSI layers**

There are 7 layers:
- **[[#1. Physical layer]]**
- **[[#2. Data link layer]]**
- **[[#3 Network layer]]**
- **[[#4 Transport layer]]**
- **[[#5. Session layer]]**
- **[[#6. Presentation layer]]**
- **[[#7. Application layer]]**

![[image-39.png|521x346]]

---
#### **1. Physical layer**
> This layer deals with the **physical connections** between devices, such as the cables, connectors, and signals that transmit data across the network. Its functions include **signal transmission**, **data encoding** and **decoding**, and **physical addressing**.

- **Keywords**: transmission media, bits, signals, physical addressing, encoding, decoding
- **Main Function:** Transmits raw bits (0s and 1s) over a physical medium.
- **Common protocols**: Ethernet, Wi-Fi, Bluetooth, USB, RS-232

---
#### **2. Data link layer**
> This layer provides reliable **transmission of data** over the **physical layer** by detecting and correcting errors, **managing flow control**, and **organizing data into frames**. It also handles the **addressing** ([[Packet routing#**MAC Adresses**|MAC (click)]]) of devices on the network.

- **Keywords**: frames, data link addressing, error detection and correction, flow control
- **Main Function:** Ensures error-free transfer of data frames between two directly connected nodes.
- **Common protocols**: Ethernet, Wi-Fi, Token Ring, HDLC, PPP

---
#### **3 Network layer**
> This layer is responsible for the **logical addressing** and **routing of data packets** between devices on different networks. It determines the best path for **data transmission** and **handles congestion control**.

- **Keywords**: **logical addressing**, **routing**, **packets**, **[[IP address| IP address (click)]]** addresses, congestion control
- **Main Function:** Determines the best physical path for data to reach its destination.
- **Common protocols**: [[IP address|IP (click)]], ICMP, ARP, RARP, OSPF, BGP

---
#### **4 Transport layer**
> This layer provides reliable **end-to-end communication** between devices by establishing a connection-oriented or connectionless communication. It also provides **flow control**, **error recovery**, and **[[Memory organisation#Segmentation**|data segmentation (click)]].**

- **Keywords**: connections, segments, flow control, error recovery, reliability
- **Main Function:** Provides reliable data transfer between end systems.
- **Common protocols**: TCP, UDP, SCTP

---
#### **5. Session layer**
> This layer establishes, maintains, and terminates **connections** between applications running on different devices. It also provides services such as **checkpointing** and recovery to ensure **reliable communication**. 

- **Keywords**: sessions, synchronization, checkpoints, recovery. 
- **Main Function:** Manages sessions (connections) between applications.
- **Common protocols**: NetBIOS, PPTP, RPC

---
#### **6. Presentation layer**
> This layer is responsible for **data representation** and **[[Encryption|Encryption (click) ]]**. It transforms data into a format that can be understood by the **application layer** and provides **encryption** and **decryption** services. 

   - **Keywords**: data formats, data conversion, encryption, decryption. 
   - **Main Function:** Translates data between the application layer and the network.
   - **Common protocols**: SSL, TLS, MIME

---
#### **7. Application layer**
> This layer provides an **interface** between the user and the network. It supports applications such as **email**, **web browsing**, **file transfer**, and **remote access**. It also provides services such as **network virtual terminal**, **file transfer access** and **management**, and **network printing**.

- **Keywords**: user interface, application protocols, data exchange, file transfer. 
- **Main Function:** Provides network services directly to user applications.
- **Common protocols**: [[Protocols#**1. HTTP (Port 80) & HTTPS (Port 443)**|HTTP (click)]], [[Protocols#**2. FTP (Port 21) & FTPS**|FTP (click)]], [[Protocols#**3. SMTP (Port 25)**|SMTP (click)]], [[Protocols#**4. POP3 (Port 110)**|POP3 (click)]], IMAP, Telnet, SSH PITOTS_12B.


