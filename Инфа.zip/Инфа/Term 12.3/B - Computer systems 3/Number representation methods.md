### **Binary & Hexadecimal Numbers**

#### **1. Binary Numbers**  
- **Definition**: Base-2 number system using only **0** and **1**.  
- **Purpose**: Fundamental language of computers (all data processed as binary).  
- **Examples**:  
  - `1010` (Binary) = 10 (Decimal)  
  - `1101` (Binary) = 13 (Decimal)  
---
#### **2. Hexadecimal Numbers**  
- **Definition**: Base-16 number system using digits **0-9** and letters **A-F** (A=10, B=11, ..., F=15).  
- **Purpose**: Shorthand for binary (1 hex digit = 4 binary digits).  
- **Examples**:  
  - `A3` (Hex) = `10100011` (Binary) = 163 (Decimal)  
  - `FF` (Hex) = `11111111` (Binary) = 255 (Decimal)  
---
#### **Key Conversions**  
| **Binary** | **Hex** | **Decimal** |  
|------------|---------|-------------|  
| `0000`     | `0`     | 0           |  
| `1010`     | `A`     | 10          |  
| `1111`     | `F`     | 15          |  

---
### **Conversions**

#### **1. Binary to Decimal**  
**Method**: Multiply each bit by \(2^n\) (where \(n\) is its position, starting from 0 on the right) and sum the results.  

**Example**: Convert `1101` (binary) to decimal.  
```
1  1  0  1  
↓  ↓  ↓  ↓  
1×2³ + 1×2² + 0×2¹ + 1×2⁰  
= 8 + 4 + 0 + 1  
= 13 (decimal)  
```

---

#### **2. Decimal to Binary**  
**Method**: Divide the number by 2 repeatedly, noting remainders (LSB to MSB).  

**Example**: Convert `25` (decimal) to binary.  
```
25 ÷ 2 = 12 (remainder 1)  
12 ÷ 2 = 6  (remainder 0)  
6 ÷ 2 = 3   (remainder 0)  
3 ÷ 2 = 1   (remainder 1)  
1 ÷ 2 = 0   (remainder 1)  
```
**Binary**: Read remainders **bottom-up** → `11001`  

---

#### **3. Decimal to Hexadecimal**  
**Method**: Divide the number by 16 repeatedly, noting remainders (convert 10-15 to A-F).  

**Example**: Convert `300` (decimal) to hex.  
```
300 ÷ 16 = 18 (remainder 12 → C)  
18 ÷ 16 = 1   (remainder 2 → 2)  
1 ÷ 16 = 0    (remainder 1 → 1)  
```
**Hex**: Read remainders **bottom-up** → `12C`  

---
#### **4. Hexadecimal to Decimal**
**Method**: Multiply each bit by \(16^n\) (where \(n\) is its position, starting from 0 on the right) and sum the results.  

**Example 1**: Convert `1A3` (hex) to decimal.

```
  1    A    3  
  ↓    ↓    ↓  
1×16² + 10×16¹ + 3×16⁰  
= 256 + 160 + 3  
= 419 (decimal)
```
---
#### **5. Binary to Hexadecimal and Hexadecimal to Binary**
![[image-28.png|310x310]]  ![[image-30.png|379x307]]


#### **Quick Reference Table**  
| **Conversion**   | **Method**                                  | **Example**         |     |
| ---------------- | ------------------------------------------- | ------------------- | --- |
| Binary → Decimal | Sum \(2^n\) for each `1` bit                | `1010` → \(8+2=10\) |     |
| Decimal → Binary | Divide by 2, track remainders (LSB→MSB)     | `13` → `1101`       |     |
| Decimal → Hex    | Divide by 16, convert remainders ≥10 to A-F | `255` → `FF`        |     |
| Hex → Decimal    | Sum \(16^n\) for each bit                   | `1A3` → `419`       |     |


### **Binary operations**
#### **Binary addition**
https://www.cuemath.com/numbers/binary-addition/ - full detailed breakdown

Simply, same as decimal addition
![[image-32.png|343x350]]

---
#### **Binary multiplication**
https://www.cuemath.com/numbers/binary-multiplication/ - detailed breakdown

![[image-33.png|519x339]]

---
#### **Binary substraction**

##### **Signed Binary Numbers & Two's Complement**

##### **1. Representing Signed Numbers in Binary**
- **Sign Bit Rule**:
  - **MSB (Most Significant Bit)** determines sign:
    - `0` → Positive number  
    - `1` → Negative number  
- **Examples**:
  - `0000 0101` = +5 (positive)  
  - `1111 1011` = -5 (negative, using two's complement)  

##### **2. Two's Complement Representation**
Used to represent negative numbers in binary within an *n-bit* range.

##### **Negative Number Conversion**  
| **Step**             | **Example: -25**       | **Action**                        |
| -------------------- | ---------------------- | --------------------------------- |
| i) Convert to binary | `11001` (25 in binary) | Standard binary conversion        |
| ii) Add leading 0    | `011001` (6-bit)       | Pad to match bit length           |
| iii) Flip all bits   | `100110`               | Invert every bit (0→1, 1→0)       |
| iv) Add 1            | `100111`               | Final two's complement form (-25) |

##### **Positive Number Conversion**  
| **Step**               | **Example: +25**          | **Action**                              |
|------------------------|--------------------------|----------------------------------------|
| i) Convert to binary   | `11001` (25 in binary)   | Standard binary conversion             |
| ii) Add leading 0      | `011001` (6-bit)         | Pad to match bit length (MSB=0)       |

##### **3. Complement Subtraction (X - Y = X + (-Y))**
**Example**: Subtract `Y=78` from `X=82` (`0100 1110 - 0101 0010`)  

##### **Step 1: Find -Y (Two's Complement of 78)**
1. Start with `Y = 0100 1110` (78 in binary).  **Add leading 0** 
2. **Flip all bits :  
   ```
   0100 1110 → 1011 0001 
   ```

##### **Step 2: Add 1 to Y
   ```
   1011 0001 → 1011 0010 (-78 in two's complement)
   ```
##### **Step 3: Add X + (-Y)**
```
   X:  0101 0010  (82)  
  -Y:  1011 0010 + (-78)  
       ---------  
       0000 0100  (4)  
```
- **Ignore overflow bit** (9th bit).  
- Result: `0000 0100` = **4** (correct: 82 - 78 = 4).  

##### **4. Key Concepts**
- **Range of n-bit Two's Complement**:  
  - Positive: `0` to \(2^{n-1}-1\) (e.g., 8-bit: 0 to 127).  
  - Negative: \(-2^{n-1}\) to \(-1\) (e.g., 8-bit: -128 to -1).  
- **Why Two's Complement?**  
  - Simplifies arithmetic (no separate subtraction circuit needed).  
  - Eliminates negative zero (unlike one's complement).  

---
### **Binary numbers with a fixed point**
#### **1. Fixed-Point Binary Representation (12.1.1.6)**

**Definition**:  
> A method to represent fractional numbers in binary by fixing the position of the "binary point" (similar to a decimal point).

**How It Works**:

- The binary number is divided into **integer part** (left of the point) and **fractional part** (right of the point).
    
- Each bit in the fractional part represents a negative power of 2:
    - **Bit positions**: 2−12−1 (0.5), 2−22−2 (0.25), 2−32−3 (0.125), etc.

**Example**:  
Represent `5.625` in 8-bit fixed-point (4 bits integer, 4 bits fractional):

1. **Integer part**: `5` = `0101`

2. **Fractional part**: `0.625` = `0.101` (since 0.5 + 0.125 = 0.625)
    
3. **Combined**: `0101.1010`
---
### **Binary numbers with a floating point**
#### **2. Floating-Point Binary Representation (12.1.1.7)**

**Definition**:  
> A method to represent very large or small numbers using a **sign bit**, **exponent**, and **mantissa** (scientific notation in binary).
![[image-34.png]]



**IEEE 754 Standard (32-bit)**:

| **Component**    | **Bits** | **Purpose**                            |
| ---------------- | -------- | -------------------------------------- |
| **Sign (S)**     | 1        | `0`=positive, `1`=negative             |
| **Exponent (E)** | varies   | Stores power of 2 (biased by +127)     |
| **Mantissa (M)** | varies   | Fractional part (implied leading `1.`) |

**Example**: Convert `-13.625` to IEEE 754:

1. **Sign bit**: `1` (negative).
    
2. **Binary integer part**: `13` = `1101`.
    
3. **Binary fractional part**: `0.625` = `0.101` → Combined: `1101.101`.
    
4. **Normalize**: `1.101101 × 2³` 

---
#### **Normalisation**
**Normal Form:**
> **Positive number** - 0.#### (**mantissa**) * 0###### (**exponent**)
> **Negative number** - 1.#### (**mantissa**) * 0###### (**exponent**)
> **Exponent** could be **negative** - 1#####
##### **Normalising Positive number**
1. **Convert decimal into binary**
    17.75 --> 10001.11
2. **Move point to the most left**
   - If first digit is 0, put point to the right of it
   - If first digit is 1, put point to the left of it and add zero to the left
      .1000111 --> 0.1000111
1. **The exponent is equal to the number of digits moved in (2)**
      - if point moved to the left - exponent positive (first digit is 0)
            5 = 0101
      - if point moved to right - exponent negative (first digit is 1)
**Result - 0.1000111 (mantissa) * 0101 (exponent)**
##### **Normalising Negative number**
1. **Convert negative decimal into negative binary**
    17.75 --> 10001.11
    10001.11 -> 01110.00
    01110.00 + 1 = 01110.01
    Add 1 to the left, because it is a negative number - 101110.01
2. **Move point to the most left digit "1"**
      101110.01 - 1.0111001
3. **The exponent is equal to the number of digits moved in (2)**
      - if point moved to the left - exponent positive (first digit is 0)
            5 = 0101
      - if point moved to right - exponent negative (first digit is 1)
         Example: -5 = 1011
