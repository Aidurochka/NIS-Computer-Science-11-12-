---
tags:
  - Copyright
  - Security
  - Data-protection
  - Protection
---
### **Information Systems Protection & Copyright**

- **[[#Copyright Fundamentals]]**
- **[[#Copyright Protection Methods]]**
- **[[#Ethical & Legal Issues]]**
- **[[#Privacy Policies]]**
---
#### **Copyright Fundamentals**
[[Ethics and Ownership#Copyright|Copyright]]
- **Definition**: Legal protection granting creators exclusive rights to their original works (software, music, films, etc.)
- **Components**:
  - *Property rights*: Economic benefits (e.g., royalties)
  - *Non-property rights*: Moral rights (e.g., attribution)
- **Related Rights**: Protect performers, producers, and broadcast organizations (phonograms, broadcasts)
---
#### **Copyright Protection Methods**
| **Method**    | **Description**                                   | **Examples**                                |
| ------------- | ------------------------------------------------- | ------------------------------------------- |
| **Licensing** | Legal agreement specifying permitted software use | Single-user licenses, enterprise licenses   |
| **DRM**       | Management of legal<br>access to digital content. | DVD copy protection, e-book printing limits |
[[Licensing]]

---
#### **Ethical & Legal Issues**
- **System Cracking**:
  - Unauthorized access violates copyright laws
  - Ethical dilemma: Balancing information freedom vs. creator rights
- **Malware Impacts**:
  - Data theft, system damage
  - Legal consequences under cybercrime laws
---
#### **Privacy Policies**
- Govern data collection/usage by organizations
- Often integrated with DRM systems to protect user information

