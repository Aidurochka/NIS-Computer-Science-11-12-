#### **Data mirroring**
**Redundant Array of Independent Disks** (**RAID**)- is a way of storing the same data in different places on multiple hard disks to protect data in the case of a drive failure.

#### **RAID types**

| RAID 0                          | RAID 1                                   |
| ------------------------------- | ---------------------------------------- |
| striping                        | mirroring                                |
| no redundancy, data is stripped | replication of data to two or more disks |
| ![[image-24.png\|181x253]]      | ![[image-25.png\|181x253]]               |
