---
tags:
  - programming
---

# Programming Languages

A programming language is a vocabulary and set of grammatical rules (syntax) used for instructing a computer to perform specific tasks.

---

# Generations of Programming Languages

```mermaid
mindmap
  root((Programming Languages))
    Low Level Languages
        1GL - Machine Code
             Binary
        2GL - Assembly
    High Level Languages
        3GL - Procedural
             C/Java/Python
        4GL - Declarative
             SQL/MATLAB
        5GL - AI-Based
             Prolog
```

There are five generations of programming languages:
1. [[#1. First-Generation Language 1GL|First-Generation (1GL)]]: Machine languages
2. [[#2. Second-Generation Language 2GL|Second-generation (2GL)]]: Assembly languages
3. [[#3. Third-Generation Language 3GL|Third-generation (3GL)]]: Procedural languages
4. [[#4. Fourth-Generation Language 4GL|Fourth-generation (4GL)]]: Non-procedural languages
5. [[#5. Fifth-Generation Language 5GL|Fifth-generation (5GL)]]: AI-based languages

---

## 1. First-Generation Language (1GL)
**Machine Language** - Direct binary code (0s and 1s)

### Characteristics:
- Hardware-specific architecture
- Statements written in binary
- No translation required
- Direct hardware interaction
### Advantages vs Disadvantages:

| Advantages                 | Disadvantages                     |
| -------------------------- | --------------------------------- |
| ✅ Extremely fast execution | ❌ Only understandable by machines |
| ✅ No translator needed     | ❌ Machine-dependent               |
| ✅ Direct hardware control  | ❌ Nearly impossible to debug      |

---

## 2. Second-Generation Language (2GL)
**Assembly Language** - Human-readable mnemonics
### Key Features:
- Uses symbolic instruction codes (MOV, ADD, SUB)
- Requires assembler conversion
- Low-level but more readable than binary
- Still hardware-specific

### Example:
```assembly
MOV AL, 61h  ; Load AL with 97 decimal (61 hex)
```

### Advantages vs Disadvantages:

| Advantages                    | Disadvantages                       |
| ----------------------------- | ----------------------------------- |
| ✅ Easier than machine code    | ❌ Still requires hardware knowledge |
| ✅ Better error identification | ❌ Needs assembler                   |
| ✅ Efficient hardware control  | ❌ Not portable across architectures |

---

## 3. Third-Generation Language (3GL)
**Procedural Languages** - High-level English-like syntax

### Characteristics:
- Requires compiler/interpreter
- **Platform-independent**
- Structured programming
- Examples: C, Java, Python, FORTRAN

### Advantages vs Disadvantages:

| Advantages                  | Disadvantages                    |
| --------------------------- | -------------------------------- |
| ✅ Human-readable syntax     | ❌ Compilation overhead           |
| ✅ Portable across machines  | ❌ Less hardware control          |
| ✅ Rich libraries/frameworks | ❌ Potential performance overhead |

---

## 4. Fourth-Generation Language (4GL)
**Non-Procedural Languages** - [[Declarative and imperative programming languages|Declarative]] programming
### Key Aspects:
- Focus on "what to do(result)" not "how to execute(process)" 
- Database and report generation
- Examples: SQL, MATLAB, Foxpro

### SQL Example:
```sql
SELECT name FROM users WHERE age > 30;
```

### Advantages vs Disadvantages:

| Advantages | Disadvantages |
|------------|---------------|
| ✅ Rapid development | ❌ High memory usage |
| ✅ Beginner-friendly | ❌ Limited hardware access |
| ✅ Domain-specific optimization | ❌ Less flexible than 3GL |

---

## 5. Fifth-Generation Language (5GL)
**AI-Based Languages** - Constraint-driven programming

### Features:
- Visual programming interfaces
- Natural language processing
- Examples: [[Prolog]], Mercury, OPS5

### Prolog Example:
```prolog
father(john, bob).
ancestor(X, Y) :- father(X, Y).
```

### Advantages vs Disadvantages:

| Advantages                  | Disadvantages                |
| --------------------------- | ---------------------------- |
| ✅ Natural language-like     | ❌ Requires powerful hardware |
| ✅ Automatic problem-solving | ❌ Steep learning curve       |
| ✅ AI/ML integration         | ❌ Limited low-level control  |

---

## Classification Summary

**Low-Level Languages**:
- [[#1. First-Generation Language 1GL|1GL (Machine Code)]]
- [[#2. Second-Generation Language 2GL|2GL (Assembly)]]

**High-Level Languages**:
- [[#3. Third-Generation Language 3GL|3GL (Procedural)]]
- [[#4. Fourth-Generation Language 4GL|4GL (Declarative)]]
- [[#5. Fifth-Generation Language 5GL|5GL (AI-Based)]]


| Metric               | Machine Language         | Assembly Language          | High-level Languages     |
| -------------------- | ------------------------ | -------------------------- | ------------------------ |
| **Execution Time**   | Fastest (no translation) | Moderate (needs assembler) | Slowest (needs compiler) |
| **Performance**      | Maximum efficiency       | Good efficiency            | Lower efficiency         |
| **Development Time** | Very slow                | Moderate                   | Fastest                  |
| **Skill Required**   | Expert-level             | Intermediate               | Beginner-friendly        |
| **Abstraction**      | None (binary)            | Low (mnemonics)            | High (English-like)      |

## High-Level vs Low-Level Languages

| Category            | High-Level Languages                                                      | Low-Level Languages                                                                    |
| ------------------- | ------------------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
| **Ease of Use**     | Programmer friendly<br>Easy to write, debug and maintain<br>Easy to learn | Difficult to develop, debug and maintain<br>Programmer must know computer architecture |
| **Performance**     | Comparatively slower<br>Less memory efficient                             | Fast execution<br>Memory efficient                                                     |
| **Abstraction**     | Higher level of abstraction<br>Machine independent                        | Direct hardware access<br>Direct manipulation of registers/storage                     |
| **Portability**     | Machine independent                                                       | Machine dependent and not portable                                                     |
| **Translation**     | Requires translation (compiler/interpreter)<br>Takes additional time      | No translation needed<br>Cuts compilation time                                         |
| **Error Handling**  | Less error prone<br>Easy to find and debug errors                         | More error prone                                                                       |
| **Hardware Access** | Cannot communicate directly with hardware                                 | Can directly communicate with hardware devices                                         |

# Little Man Computer (LMC) 

**Little Man Computer (LMC)** is a simulator that mimics the modern computer
architecture, known as von Neumann architecture.

![[Pasted image 20250331153200.png]]

**Examples**:
      Write a program to A+B-C:
00 INP A
01 STA A
02 INP B
03 STA B
04 INP C
05 STA C
06 LOAD A
07 ADD B
08 ADD C
09 OUT
10 HLT


# Trace table 

**Trace table** - a technique used to test an algorithm and predict step by step how the
computer will run the algorithm.

It can be used to understand or predict what an algorithm is doing and to identify
potential logic errors (when the program compiles but does not produce the expected
output).

