---
tags:
  - computer-systems
  - CPU
---
[[Von Neumann CPU Architecture.canvas|Von Neumann CPU Architecture(click)]]: a technique for building a **processor** where data and instructions are stored in the %% same %% memory and accessed via **buses**

---
# Computer Architecture Components

## [[Memory]]
| Meta memory stores data and instructions that will be used by the processor. |

## Processor Operation
The processor is connected to memory which sends instructions it should execute. This is commonly known as the [[Fetch-Execute-Cycle]] and is a key principle in modern computing.

## Devices
**Input device**: Any hardware that allows a human operator or other systems to interface with a computer.
- **Examples of input devices**: keyboard, mouse, scanner, web camera
- **Examples of output devices**: monitor, printer, speakers

## Central Processing Unit (CPU)
The component of a computer system that:
- Performs the basic operations (such as processing data)
- Exchanges data with the system's memory or peripherals
- Manages the system's other components
Also called "the brain of the computer"

### CPU Components
##### 1. **Control Unit (CU)**: Part of the processor that manages the execution of instructions. The CU performs these functions:
- Reads and decodes instructions
- Sends control signals that control hardware
- Manages overall system control

##### 2. **Arithmetic Logic Unit (ALU)**: Part of the processor that performs arithmetic and logic operations.
- Where calculations are done and decisions are made
- Works with registers in a Von Neumann architecture
- Data is transferred between these components through buses

##### 3. **Registers**: Small amounts of high-speed memory contained within the CPU. They store small amounts of data needed during processing, such as:
- The address of the next instruction to be executed
- The current instruction being decoded
- Intermediate calculation results



## [[Memory## Cache Memory|Cache]]
A high-speed temporary area of memory that stores information the processor is likely to need. This means the processor doesn't have to wait for data and instructions to be fetched from RAM.

## [[System bus|Buses (click)]]
Microscopic parallel wires that transmit data between the processor and other components.

**Types of [[System bus|buses]]**:
- **Address bus**: Carries memory addresses from the processor to other components
- **Data bus**: Carries the actual data between the processor and other components
- **Control bus**: Sends control signals to coordinate the registers, data and address buses

## Clock
A device that generates signals used to synchronize the components of a computer.

# Von Neumann's Principles

1. **Binary Number System**  
   The use of the binary number system in computers. The advantage over decimal notation is that devices can be made simple enough, and arithmetic and logical operations in binary notation are also quite simple.

2. **Stored-Program Concept**  
   The work of the computer is controlled by a program consisting of a set of instructions. The commands are executed consecutively one after the other. Creating a machine with a program stored in memory was the beginning of what we now call programming.

3. **Unified Memory for Data and Programs**  
   The computer's memory is used not only for storing data but also for programs. In this case, both program instructions and data are encoded in a binary number system. Their method of recording is the same. Therefore, in certain situations, you can perform the same actions on commands as on data.

4. **Addressable Memory**  
   The memory of the computer has addresses that are sequentially numbered. At any time, you can access any memory location by its address. This principle opened the possibility of using variables in programming.

5. **Conditional Branching**  
   The possibility of a conditional transition during program execution. Despite the fact that commands are executed sequentially, programs can implement the ability to jump to any section of the code.