---
tags:
  - computer-systems
  - software
---


**Hardware** - a common term for the physical parts of the computer, both **internal** and **external**.
Two types:
1. **External Components (Peripherals):**  
External **hardware** components are parts that you can touch, such as a monitor, mouse, keyboard, and printer. These components are used to retrieve data from or send data to the system. Therefore, they are called input or output devices (I/O).
2. **Internal Components (Processing and Storage):**  
Internal **hardware** components are located inside the computer case and include a processor, hard drive, memory chips, sound cards, video cards, and circuits necessary to connect all these devices to each other.