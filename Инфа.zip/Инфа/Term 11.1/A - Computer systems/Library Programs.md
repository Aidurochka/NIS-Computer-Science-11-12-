---
tags:
  - computer-systems
  - system-software
---

### **Library Programs:**
Pre-written code, data, or resources that can be reused by other programs to avoid redundancy.
- **Examples:** Math libraries, graphics libraries (e.g., OpenGL), standard function libraries.