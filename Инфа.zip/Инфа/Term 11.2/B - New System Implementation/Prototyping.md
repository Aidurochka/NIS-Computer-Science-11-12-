
# System Development Concepts

## 1. Prototyping (11.2.3.4-11.2.3.6)

Prototyping is **the process of designing a mock-up (макет) of a product or process ahead of creating a final design**
### Advantages vs Disadvantages
| Advantages | Disadvantages |
|------------|---------------|
| ✅ Reduced development time and costs | ❌ Potential insufficient analysis |
| ✅ Improved user involvement | ❌ Confusion between prototype/final system |
| ✅ Early UI/UX validation | ❌ Developer attachment to prototypes |
| ✅ Faster feedback cycles | ❌ Additional implementation expenses |

### Prototyping Process
![[Pasted image 20250402192312.png]]

**Example Use Case**:  
Developing a mobile app interface to validate:
- Navigation flow
- Button placements
- User experience

## 2. New System Considerations (11.2.2.1-11.2.2.2)

### Advantages vs Restrictions of new system creation

| Advantages                     | Restrictions                        |
| ------------------------------ | ----------------------------------- |
| 🌍 Wider audience reach        | 🔒 Privacy concerns                 |
| 💼 Easy information access     | 💰 High labor costs                 |
| 🔄 Easy content updates        | ⚠️ Quality assurance challenges     |
| 📢 Viral marketing potential   | 😠 Negative publicity risks         |
| 🏆 Service quality improvement | 📩 Spam and unwanted communications |

## 3. Development Frameworks (11.2.2.3)
   A framework, or software framework, is a platform for developing software applications.
### Framework Characteristics
- Consistent **object-oriented programming** environment
- Secure code execution
- Version conflict minimization
- Cross-application compatibility
- Industry standard compliance

### Framework Types
```mermaid
mindmap
  root((Frameworks))
    Web
      Django - Python
      Symfony - PHP
      Express - JavaScript
    Application
      .NET
      Visual Studio - C#
      Spring Boot
    Mobile
      React Native
      Flutter
      Xamarin
```

## 4. Technical Specifications (11.2.2.7, 11.3.1.5)

### Minimum hardware requirements for the operation of certain software:

| Hardware                      | Minimum Requirement | Reason                                        |
| ----------------------------- | ------------------- | --------------------------------------------- |
| Processor speed               | 1.6GHZ              | Accommodate most PCs                          |
| Memory of user PC             | 512MB RAM           | Relatively fast                               |
| Disk Space of user PC         | 5GB                 | Adequate Storage capacity                     |
| Memory of server PC           | 8GB                 | Fast                                          |
| Bandwidth(network connection) | 15Mbps              | Relatively Good                               |
| Disk space of server          | 200GB               | Adequate Storage for database and application |
PS: агай сказал просто запомнить и не важно что инфа сильно устарела