---
tags:
  - Protocols
  - POP3
  - FTP
  - HTTP
  - SMTP
---

## Network Protocols Overview
A **protocol** is a set of rules enabling computers to communicate over a network. Different protocols serve specific purposes in data transmission.  

---

### **Key Protocols & Their Roles**

There are 4 main protocols:
- **[[#**1. HTTP (Port 80) & HTTPS (Port 443)**|1. HTTP (Port 80) & HTTPS (Port 443)]]**
- **[[#**2. FTP (Port 21) & FTPS**|2. FTP (Port 21) & FTPS]]**
- **[[#**3. SMTP (Port 25)**|3. SMTP (Port 25)]]**
- **[[#**4. POP3 (Port 110)**|4. POP3 (Port 110)]]**

---

#### **1. HTTP (Port 80) & HTTPS (Port 443)**  
>  HTTP/HTTPS (Hypertext Transfer Protocol/Secure)
- **HTTP** – Used by web browsers to request and display webpages (unencrypted).  
- **HTTPS** – Secure version of HTTP with encryption for safe transactions (e.g., online banking).  
  - *Why it matters*: HTTPS protects sensitive data from interception.  
---
#### **2. FTP (Port 21) & FTPS**  
- **FTP** (File Transfer Protocol) – Transfers files across a **network and Internet** but lacks encryption (risky for sensitive data).  
- **FTPS** – Secure FTP variant that encrypts file transfers.  
---
#### **3. SMTP (Port 25)**  
SMTP - Simple Mail Transfer Protocol
- Governs **sending emails** from a client to a mail server (e.g., Outlook to Gmail’s server).  
  - *Note*: Only handles outgoing mail; doesn’t retrieve emails.  
---
#### **4. POP3 (Port 110)**  
POP3 - The Post Office Protocol
- Allows email clients (e.g., Thunderbird) to **download emails** from a remote server to a local device.  

---

### **Why Protocols Matter**  
- **Standardization** – Ensures devices worldwide communicate seamlessly.  
- **Security** – Protocols 
- like HTTPS and FTPS safeguard data.  
- **Efficiency** – Dedicated ports (e.g., 80 for HTTP) streamline traffic management.  
